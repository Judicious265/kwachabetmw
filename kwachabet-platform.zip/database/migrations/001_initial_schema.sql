-- ============================================================
-- KWACHA BET - Complete Database Schema
-- PostgreSQL 15+  |  All tables, indexes, constraints
-- ============================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── USERS ───────────────────────────────────────────────────────────────────

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone           VARCHAR(15) UNIQUE NOT NULL,  -- +265XXXXXXXXX
    email           VARCHAR(255) UNIQUE,
    full_name       VARCHAR(255) NOT NULL,
    date_of_birth   DATE NOT NULL,
    is_verified     BOOLEAN DEFAULT FALSE,
    is_active       BOOLEAN DEFAULT TRUE,
    is_suspended    BOOLEAN DEFAULT FALSE,
    suspension_reason TEXT,
    kyc_status      VARCHAR(20) DEFAULT 'pending'  -- pending|approved|rejected
                    CHECK (kyc_status IN ('pending','approved','rejected')),
    pin_hash        VARCHAR(255),                  -- bcrypt hashed 4-digit PIN
    password_hash   VARCHAR(255) NOT NULL,
    referral_code   VARCHAR(10) UNIQUE NOT NULL,
    referred_by     UUID REFERENCES users(id),
    risk_score      SMALLINT DEFAULT 0 CHECK (risk_score BETWEEN 0 AND 100),
    last_login_at   TIMESTAMPTZ,
    last_login_ip   INET,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_referral ON users(referral_code);
CREATE INDEX idx_users_risk ON users(risk_score);

-- ─── DEVICE / SESSION TRACKING ───────────────────────────────────────────────

CREATE TABLE user_sessions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_fingerprint VARCHAR(255),
    ip_address      INET NOT NULL,
    country_code    VARCHAR(3),
    city            VARCHAR(100),
    user_agent      TEXT,
    is_active       BOOLEAN DEFAULT TRUE,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_user ON user_sessions(user_id);
CREATE INDEX idx_sessions_device ON user_sessions(device_fingerprint);
CREATE INDEX idx_sessions_ip ON user_sessions(ip_address);

-- ─── OTP ─────────────────────────────────────────────────────────────────────

CREATE TABLE otp_codes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone       VARCHAR(15) NOT NULL,
    code_hash   VARCHAR(255) NOT NULL,             -- bcrypt of 6-digit OTP
    purpose     VARCHAR(30) NOT NULL               -- register|login|withdrawal|pin_reset
                CHECK (purpose IN ('register','login','withdrawal','pin_reset')),
    attempts    SMALLINT DEFAULT 0,
    is_used     BOOLEAN DEFAULT FALSE,
    expires_at  TIMESTAMPTZ NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_otp_phone ON otp_codes(phone, purpose);

-- ─── WALLETS ─────────────────────────────────────────────────────────────────

CREATE TABLE wallets (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    balance         NUMERIC(18,2) DEFAULT 0.00 CHECK (balance >= 0),
    bonus_balance   NUMERIC(18,2) DEFAULT 0.00 CHECK (bonus_balance >= 0),
    locked_amount   NUMERIC(18,2) DEFAULT 0.00,   -- funds locked in active bets
    currency        CHAR(3) DEFAULT 'MWK',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_wallets_user ON wallets(user_id);

-- ─── TRANSACTIONS ─────────────────────────────────────────────────────────────

CREATE TABLE transactions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    wallet_id       UUID NOT NULL REFERENCES wallets(id),
    type            VARCHAR(30) NOT NULL
                    CHECK (type IN (
                      'deposit','withdrawal','bet_stake','bet_win',
                      'bet_refund','bonus_credit','referral_bonus','adjustment'
                    )),
    amount          NUMERIC(18,2) NOT NULL,
    balance_before  NUMERIC(18,2) NOT NULL,
    balance_after   NUMERIC(18,2) NOT NULL,
    reference       VARCHAR(100) UNIQUE,          -- external payment reference
    payment_method  VARCHAR(30),                  -- airtel|mpamba|bank|system
    status          VARCHAR(20) DEFAULT 'pending'
                    CHECK (status IN ('pending','completed','failed','reversed')),
    metadata        JSONB DEFAULT '{}',
    fraud_flagged   BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_txn_user ON transactions(user_id);
CREATE INDEX idx_txn_status ON transactions(status);
CREATE INDEX idx_txn_type ON transactions(type);
CREATE INDEX idx_txn_reference ON transactions(reference);
CREATE INDEX idx_txn_created ON transactions(created_at DESC);

-- ─── DEPOSITS ────────────────────────────────────────────────────────────────

CREATE TABLE deposits (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    transaction_id  UUID REFERENCES transactions(id),
    amount          NUMERIC(18,2) NOT NULL CHECK (amount >= 500),
    payment_method  VARCHAR(30) NOT NULL,
    provider_ref    VARCHAR(100),                 -- provider transaction ID
    phone_used      VARCHAR(15),
    status          VARCHAR(20) DEFAULT 'pending'
                    CHECK (status IN ('pending','completed','failed','expired')),
    checkout_url    TEXT,
    webhook_data    JSONB,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── WITHDRAWALS ──────────────────────────────────────────────────────────────

CREATE TABLE withdrawals (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    transaction_id  UUID REFERENCES transactions(id),
    amount          NUMERIC(18,2) NOT NULL CHECK (amount >= 500),
    payment_method  VARCHAR(30) NOT NULL,
    destination     VARCHAR(20) NOT NULL,          -- phone number or account
    status          VARCHAR(30) DEFAULT 'pending'
                    CHECK (status IN (
                      'pending','processing','completed','failed',
                      'cancelled','flagged','manual_review'
                    )),
    is_auto         BOOLEAN DEFAULT TRUE,           -- false = manual approval required
    approved_by     UUID REFERENCES users(id),
    approved_at     TIMESTAMPTZ,
    fraud_score     SMALLINT DEFAULT 0,
    admin_notes     TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_withdrawals_user ON withdrawals(user_id);
CREATE INDEX idx_withdrawals_status ON withdrawals(status);

-- ─── SPORTS & EVENTS ─────────────────────────────────────────────────────────

CREATE TABLE sports (
    id          VARCHAR(50) PRIMARY KEY,           -- football|basketball|tennis|etc
    name        VARCHAR(100) NOT NULL,
    is_active   BOOLEAN DEFAULT TRUE
);

CREATE TABLE events (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    external_id     VARCHAR(100) UNIQUE,           -- from odds API
    sport_id        VARCHAR(50) REFERENCES sports(id),
    home_team       VARCHAR(200) NOT NULL,
    away_team       VARCHAR(200) NOT NULL,
    league          VARCHAR(200),
    commence_time   TIMESTAMPTZ NOT NULL,
    status          VARCHAR(20) DEFAULT 'upcoming'
                    CHECK (status IN ('upcoming','live','finished','cancelled')),
    home_score      SMALLINT,
    away_score      SMALLINT,
    result          VARCHAR(10),                   -- home|away|draw
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_events_sport ON events(sport_id);
CREATE INDEX idx_events_status ON events(status);
CREATE INDEX idx_events_commence ON events(commence_time);
CREATE INDEX idx_events_external ON events(external_id);

-- ─── MARKETS & ODDS ──────────────────────────────────────────────────────────

CREATE TABLE markets (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id    UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    market_type VARCHAR(50) NOT NULL,             -- h2h|spreads|totals
    outcome     VARCHAR(100) NOT NULL,            -- Home|Away|Draw
    odds        NUMERIC(8,3) NOT NULL CHECK (odds > 1),
    bookmaker   VARCHAR(50),
    is_active   BOOLEAN DEFAULT TRUE,
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_markets_event ON markets(event_id);
CREATE UNIQUE INDEX idx_markets_unique ON markets(event_id, market_type, outcome);

-- ─── BET TICKETS ─────────────────────────────────────────────────────────────

CREATE TABLE tickets (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    ticket_code     VARCHAR(20) UNIQUE NOT NULL,  -- KB-XXXXXXXX
    type            VARCHAR(20) NOT NULL
                    CHECK (type IN ('single','accumulator','live')),
    stake           NUMERIC(18,2) NOT NULL CHECK (stake >= 50),
    bonus_stake     NUMERIC(18,2) DEFAULT 0,      -- from bonus wallet
    total_odds      NUMERIC(10,3) NOT NULL,
    potential_win   NUMERIC(18,2) NOT NULL,
    actual_win      NUMERIC(18,2),
    tax_deducted    NUMERIC(18,2) DEFAULT 0,       -- withholding tax
    status          VARCHAR(20) DEFAULT 'pending'
                    CHECK (status IN ('pending','won','lost','cancelled','cashout')),
    is_live         BOOLEAN DEFAULT FALSE,
    settled_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_tickets_user ON tickets(user_id);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_created ON tickets(created_at DESC);

CREATE TABLE ticket_selections (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_id   UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
    event_id    UUID NOT NULL REFERENCES events(id),
    market_id   UUID NOT NULL REFERENCES markets(id),
    market_type VARCHAR(50) NOT NULL,
    selection   VARCHAR(100) NOT NULL,            -- Home|Away|Draw
    odds        NUMERIC(8,3) NOT NULL,
    status      VARCHAR(20) DEFAULT 'pending'
                CHECK (status IN ('pending','won','lost','void')),
    settled_at  TIMESTAMPTZ
);

CREATE INDEX idx_selections_ticket ON ticket_selections(ticket_id);
CREATE INDEX idx_selections_event ON ticket_selections(event_id);

-- ─── FRAUD DETECTION ─────────────────────────────────────────────────────────

CREATE TABLE fraud_flags (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id),
    rule_code   VARCHAR(50) NOT NULL,
    severity    VARCHAR(10) CHECK (severity IN ('low','medium','high','critical')),
    description TEXT NOT NULL,
    metadata    JSONB DEFAULT '{}',
    resolved    BOOLEAN DEFAULT FALSE,
    resolved_by UUID REFERENCES users(id),
    resolved_at TIMESTAMPTZ,
    admin_notes TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_fraud_user ON fraud_flags(user_id);
CREATE INDEX idx_fraud_resolved ON fraud_flags(resolved);

CREATE TABLE blacklisted_devices (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fingerprint VARCHAR(255) UNIQUE NOT NULL,
    ip_address  INET,
    reason      TEXT,
    blocked_by  UUID REFERENCES users(id),
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── BONUS SYSTEM ────────────────────────────────────────────────────────────

CREATE TABLE bonus_campaigns (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(100) NOT NULL,
    type            VARCHAR(30) NOT NULL
                    CHECK (type IN ('welcome','reload','free_bet','referral','manual')),
    percent         NUMERIC(5,2),                  -- e.g. 100 for 100%
    amount          NUMERIC(18,2),                 -- fixed amount
    max_bonus       NUMERIC(18,2),
    min_deposit     NUMERIC(18,2) DEFAULT 500,
    wagering_req    NUMERIC(5,2) DEFAULT 5,         -- 5x wagering
    min_odds        NUMERIC(5,2) DEFAULT 1.5,
    expiry_days     SMALLINT DEFAULT 30,
    is_active       BOOLEAN DEFAULT TRUE,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE user_bonuses (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    campaign_id     UUID REFERENCES bonus_campaigns(id),
    type            VARCHAR(30) NOT NULL,
    bonus_amount    NUMERIC(18,2) NOT NULL,
    wagered_amount  NUMERIC(18,2) DEFAULT 0,
    required_wager  NUMERIC(18,2) NOT NULL,
    status          VARCHAR(20) DEFAULT 'active'
                    CHECK (status IN ('active','completed','expired','cancelled')),
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_bonuses_user ON user_bonuses(user_id);
CREATE INDEX idx_bonuses_status ON user_bonuses(status);

-- ─── REFERRALS ───────────────────────────────────────────────────────────────

CREATE TABLE referrals (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    referrer_id     UUID NOT NULL REFERENCES users(id),
    referred_id     UUID UNIQUE NOT NULL REFERENCES users(id),
    status          VARCHAR(20) DEFAULT 'pending'
                    CHECK (status IN ('pending','qualified','rewarded')),
    reward_amount   NUMERIC(18,2),
    rewarded_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── SMS NOTIFICATIONS ───────────────────────────────────────────────────────

CREATE TABLE sms_logs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id),
    phone       VARCHAR(15) NOT NULL,
    message     TEXT NOT NULL,
    template    VARCHAR(50),
    provider    VARCHAR(30) DEFAULT 'africastalking',
    status      VARCHAR(20) DEFAULT 'pending'
                CHECK (status IN ('pending','sent','delivered','failed')),
    provider_id VARCHAR(100),                      -- Africa's Talking message ID
    cost        NUMERIC(10,6),
    retries     SMALLINT DEFAULT 0,
    error_msg   TEXT,
    sent_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sms_user ON sms_logs(user_id);
CREATE INDEX idx_sms_status ON sms_logs(status);
CREATE INDEX idx_sms_created ON sms_logs(created_at DESC);

-- ─── ADMIN AUDIT LOG ─────────────────────────────────────────────────────────

CREATE TABLE audit_logs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_id    UUID NOT NULL REFERENCES users(id),
    action      VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id   UUID,
    details     JSONB DEFAULT '{}',
    ip_address  INET,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── SPORTS TABLE SEEDS ──────────────────────────────────────────────────────

INSERT INTO sports (id, name) VALUES
  ('football',     'Football'),
  ('basketball',   'Basketball'),
  ('tennis',       'Tennis'),
  ('ice_hockey',   'Ice Hockey'),
  ('baseball',     'Baseball'),
  ('rugby_league', 'Rugby League');

-- ─── ROW-LEVEL SECURITY (enable in production per service role) ───────────────

-- ALTER TABLE users ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;

-- ─── TRIGGERS: updated_at auto-update ────────────────────────────────────────

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_wallets_updated BEFORE UPDATE ON wallets
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_transactions_updated BEFORE UPDATE ON transactions
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_withdrawals_updated BEFORE UPDATE ON withdrawals
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
