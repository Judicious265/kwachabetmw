# Kwacha Bet — Complete Deployment & API Reference

## System Overview

Kwacha Bet is a full-stack sports betting platform built for Malawi with:
- **Frontend**: Next.js 14 (React) — dark theme, mobile-first
- **Backend**: Node.js / Express microservice-ready API
- **Database**: PostgreSQL 15 with Redis caching
- **Payments**: PayChangu (Airtel Money, TNM Mpamba, Bank)
- **SMS**: Africa's Talking (OTP, notifications)
- **Odds**: The Odds API + WebSocket live updates
- **Security**: JWT, bcrypt, PIN, fraud detection, rate limiting

---

## Prerequisites

| Tool       | Version  | Purpose              |
|------------|----------|----------------------|
| Node.js    | ≥ 20     | Runtime              |
| PostgreSQL | ≥ 15     | Primary database     |
| Redis      | ≥ 7      | Cache + queues       |
| Docker     | ≥ 24     | Container deployment |
| Nginx      | ≥ 1.25   | Reverse proxy + SSL  |

---

## 1. Quick Start (Local Development)

```bash
# Clone / unzip project
cd kwachabet

# ── Backend setup ──────────────────────────────────────────────
cd backend
cp .env.example .env
# Edit .env with your credentials (DB, Redis, API keys)
npm install
node database/migrate.js        # Run schema migration
npm run dev                     # API on http://localhost:5000

# ── Frontend setup ─────────────────────────────────────────────
cd ../frontend
cp .env.example .env.local
# Set NEXT_PUBLIC_API_URL=http://localhost:5000/api/v1
# Set NEXT_PUBLIC_WS_URL=ws://localhost:5000/ws/odds
npm install
npm run dev                     # UI on http://localhost:3000
```

---

## 2. Production Deployment (Docker)

```bash
# 1. Set environment variables
cp backend/.env.example backend/.env
# Fill in all values in backend/.env

# 2. Add SSL certificates
mkdir -p deployment/ssl
cp your-cert.crt deployment/ssl/kwachabet.crt
cp your-key.key  deployment/ssl/kwachabet.key

# 3. Launch all services
docker-compose up -d --build

# 4. Check health
curl https://api.kwachabet.mw/health

# 5. View logs
docker-compose logs -f api
docker-compose logs -f frontend
```

---

## 3. Cloud Deployment (AWS Recommended)

### Recommended Stack
- **EC2**: t3.medium (backend) + t3.small (frontend)
- **RDS**: PostgreSQL 15 Multi-AZ
- **ElastiCache**: Redis 7
- **ALB**: Application Load Balancer with SSL termination
- **S3 + CloudFront**: Static assets
- **Route 53**: DNS management

### Environment Variables Required

```env
# Core
NODE_ENV=production
JWT_SECRET=<256-bit random string>
BCRYPT_ROUNDS=12

# Database
DB_HOST=<RDS endpoint>
DB_NAME=kwachabet
DB_USER=kwachabet_user
DB_PASSWORD=<strong password>
DB_SSL=true

# Redis
REDIS_URL=redis://<elasticache-endpoint>:6379

# PayChangu (get from paychangu.com)
PAYCHANGU_API_KEY=<key>
PAYCHANGU_SECRET=<secret>
PAYCHANGU_WEBHOOK_SECRET=<webhook-secret>

# Africa's Talking (get from africastalking.com)
AT_API_KEY=<key>
AT_USERNAME=kwachabet

# The Odds API (get from the-odds-api.com)
ODDS_API_KEY=<key>

# Limits
AUTO_WITHDRAWAL_LIMIT=1000000
WELCOME_BONUS_PERCENT=100
WELCOME_BONUS_MAX_MWK=50000
```

---

## 4. API Reference

### Authentication

```
POST /api/v1/auth/register/initiate
Body: { phone, full_name, date_of_birth, password, email? }
→ Sends OTP to phone

POST /api/v1/auth/register/verify
Body: { phone, otp, referral_code? }
→ { token, user }

POST /api/v1/auth/login
Body: { phone, password }
→ { token, user }

POST /api/v1/auth/pin/set          [AUTH]
Body: { pin }                       4-digit PIN

POST /api/v1/auth/pin/verify       [AUTH]
Body: { pin }
→ { pin_token }                     Valid 5 minutes

POST /api/v1/auth/otp/withdrawal   [AUTH]
→ Sends OTP for withdrawal verification
```

### Wallet

```
GET  /api/v1/wallet/balance        [AUTH]
→ { balance, bonus_balance, available, currency }

GET  /api/v1/wallet/transactions   [AUTH]
Query: page, limit, type
→ { transactions[], pagination }

POST /api/v1/wallet/deposit        [AUTH]
Body: { amount, method: "airtel"|"mpamba"|"bank", phone? }
→ { deposit_id, checkout_url, status }

POST /api/v1/wallet/withdraw       [AUTH + PIN-TOKEN]
Body: { amount, method, destination, otp }
→ { withdrawal_id, status, message }
```

### Betting

```
POST /api/v1/betting/place         [AUTH]
Body: {
  selections: [{ market_id, selection }],
  stake,
  use_bonus?,
  is_live?
}
→ { ticket: { id, ticket_code, stake, total_odds, potential_win } }

GET  /api/v1/betting/tickets       [AUTH]
Query: page, limit, status
→ { tickets[], pagination }

GET  /api/v1/betting/tickets/:code [AUTH]
→ { ticket } with selections and events

GET  /api/v1/betting/check/:code   [PUBLIC]
→ Ticket status by code
```

### Odds & Sports

```
GET  /api/v1/odds/featured
→ { events[] } with h2h markets

GET  /api/v1/odds/events
Query: sport, status (upcoming|live)
→ { events[] }

GET  /api/v1/odds/sports
→ { sports[] }

WebSocket: wss://api.kwachabet.mw/ws/odds
→ Broadcasts: { type: "odds_update", events[] }
→ Send: { type: "subscribe_sport", sport: "football" }
```

### Admin (requires is_admin=true)

```
GET  /api/v1/admin/dashboard/stats
GET  /api/v1/admin/users?search=&risk_min=
GET  /api/v1/admin/users/:id
PATCH /api/v1/admin/users/:id/suspend   Body: { reason }
PATCH /api/v1/admin/users/:id/unsuspend
GET  /api/v1/admin/tickets?status=
GET  /api/v1/admin/withdrawals/pending
PATCH /api/v1/admin/withdrawals/:id/approve
PATCH /api/v1/admin/withdrawals/:id/reject  Body: { reason }
GET  /api/v1/admin/fraud/dashboard
PATCH /api/v1/admin/fraud/flags/:id/resolve Body: { notes }
POST /api/v1/admin/fraud/blacklist/device   Body: { fingerprint, reason }
POST /api/v1/admin/bonus/free-bet           Body: { user_id, amount, expiry_days }
GET  /api/v1/admin/bonus/campaigns
POST /api/v1/admin/bonus/campaigns
```

### Webhooks

```
POST /webhooks/paychangu
Header: verif-hash: <HMAC-SHA256 signature>
→ Handles deposit_success and withdrawal_success events
```

---

## 5. Fraud Detection Rules

| Rule Code                | Trigger                                              | Score Impact |
|--------------------------|------------------------------------------------------|-------------|
| RAPID_WITHDRAWAL         | ≥5 withdrawals in 24 hours                           | +40         |
| NEW_ACCOUNT_HIGH_WITHDRAW| Account < 30 days old AND withdrawal > MWK 100,000  | +35         |
| UNUSUAL_WIN_PATTERN      | ≥3 wins with odds > 50 in 7 days                    | +30         |
| DEVICE_MULTI_ACCOUNT     | Same device fingerprint on multiple accounts         | +50         |
| IP_MULTI_ACCOUNT         | Same IP on ≥2 other accounts                        | +25         |
| NON_MALAWI_LOGIN         | Login from outside Malawi                            | +20         |
| RAPID_DEPOSIT_WITHDRAWAL | Withdrawal ≥90% of recent deposit within 1 hour      | +45         |
| BET_RATE_LIMIT           | >30 bets per minute                                  | Block        |

**Auto-block threshold**: Score ≥ 90  
**Manual review threshold**: Score ≥ 70 on withdrawals  
**Withdrawal auto-hold**: Amount ≥ MWK 1,000,000

---

## 6. Bonus System Logic

### Welcome Bonus
1. User registers and makes first deposit
2. System credits 100% of deposit (max MWK 50,000) to bonus wallet
3. Bonus is locked until **5x wagering** on odds ≥ 1.5
4. After wagering complete → bonus converts to real balance

### Free Bets
- Admin assigns free bet to user via admin panel
- Free bet amount credited to bonus wallet
- User places bet using bonus wallet
- **Only winnings are withdrawable** (stake is non-withdrawable)
- Expires after configurable days

### Referral System
1. User shares their unique referral code
2. Friend registers using the code
3. Friend makes first deposit
4. Referrer receives MWK 2,000 credited to real wallet
5. No wagering requirement on referral bonus

---

## 7. SMS Notification Events

| Event                 | Template                                                    |
|-----------------------|-------------------------------------------------------------|
| OTP (registration)    | "Your KwachaBet code is: {otp}. Valid 5 mins."             |
| OTP (withdrawal)      | "Withdrawal OTP: {otp}. Never share this."                 |
| Welcome               | "Hi {name}! Welcome to Kwacha Bet. Start betting now!"     |
| Deposit confirmed     | "Deposit MWK {amount} received. Balance: MWK {balance}."  |
| Withdrawal completed  | "Withdrawal of MWK {amount} successful."                   |
| Bet won               | "You won MWK {amount}! Balance: MWK {balance}."            |
| Bonus awarded         | "You received a {type} bonus of MWK {amount}!"             |
| Referral reward       | "You earned MWK {amount} referral bonus!"                  |

---

## 8. Tax Compliance (Malawi)

- **Withholding Tax**: 20% deducted from all winnings before credit
- **Minimum Bet**: MWK 50
- **Maximum Payout**: MWK 10,000,000 per ticket
- All transactions logged for regulatory reporting
- User age verification enforced (18+) at registration

---

## 9. Security Checklist

- [x] JWT authentication on all protected routes
- [x] bcrypt password hashing (12 rounds)
- [x] 4-digit PIN for withdrawals (bcrypt hashed)
- [x] OTP verification for registration and withdrawals
- [x] HTTPS enforced via Nginx + HSTS
- [x] Rate limiting on auth (5/15min), API (200/15min)
- [x] Malawian phone number validation (+265 prefix)
- [x] Age verification (18+) enforced server-side
- [x] Device fingerprinting + IP tracking
- [x] Fraud score system with configurable rules
- [x] Webhook signature verification (HMAC-SHA256)
- [x] Database SSL in production
- [x] Non-root Docker user
- [x] Security headers (X-Frame-Options, CSP, HSTS)
- [x] Input validation on all endpoints (express-validator)
- [x] SQL injection protection via Sequelize ORM
- [x] Audit log for all admin actions

---

## 10. Monitoring & Maintenance

```bash
# View logs
docker-compose logs -f api --tail=100

# Database backup
docker exec kwachabet-db pg_dump -U kwachabet_user kwachabet > backup_$(date +%Y%m%d).sql

# Redis monitor
docker exec kwachabet-redis redis-cli -a $REDIS_PASSWORD monitor

# Health check
curl https://api.kwachabet.mw/health

# Scale API (multiple instances with load balancer)
docker-compose up -d --scale api=3
```

---

## 11. Support

- Platform: kwachabet.mw
- Support: support@kwachabet.mw
- Admin: admin.kwachabet.mw
- Emergency: +265 XXX XXX XXX

---

*Kwacha Bet v1.0.0 — Built for Malawi 🇲🇼*
*Bet Responsibly. 18+ Only. GamblingTherapy.org*
