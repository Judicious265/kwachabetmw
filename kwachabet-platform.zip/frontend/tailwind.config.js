/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#00C853',   // Kwacha Bet green
          dark:    '#009624',
          light:   '#5EFC82',
          glow:    'rgba(0,200,83,0.15)',
        },
        dark: {
          DEFAULT: '#0D1117',
          surface: '#161B22',
          card:    '#1C2128',
          border:  '#30363D',
          hover:   '#21262D',
        },
        accent: {
          gold:   '#FFD700',
          red:    '#F85149',
          orange: '#FB8500',
        },
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      animation: {
        'pulse-green': 'pulse-green 2s ease-in-out infinite',
        'slide-up':    'slide-up 0.3s ease-out',
        'odds-flash':  'odds-flash 0.5s ease-in-out',
        'ticker':      'ticker 30s linear infinite',
      },
      keyframes: {
        'pulse-green': {
          '0%,100%': { boxShadow: '0 0 0 0 rgba(0,200,83,0)' },
          '50%':      { boxShadow: '0 0 0 8px rgba(0,200,83,0.15)' },
        },
        'slide-up': {
          from: { transform: 'translateY(20px)', opacity: '0' },
          to:   { transform: 'translateY(0)',    opacity: '1' },
        },
        'odds-flash': {
          '0%,100%': { background: 'transparent' },
          '50%':     { background: 'rgba(0,200,83,0.25)' },
        },
        'ticker': {
          from: { transform: 'translateX(100%)' },
          to:   { transform: 'translateX(-100%)' },
        },
      },
    },
  },
  plugins: [],
};
