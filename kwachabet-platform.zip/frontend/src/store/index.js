/**
 * Global State Store - Zustand
 * Auth state, wallet balance, bet slip management
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import Cookies from 'js-cookie';

// ─── Auth Store ───────────────────────────────────────────────────────────────

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      login: (user, token) => {
        Cookies.set('kb_token', token, { expires: 7, secure: true, sameSite: 'strict' });
        set({ user, token, isAuthenticated: true });
      },

      logout: () => {
        Cookies.remove('kb_token');
        set({ user: null, token: null, isAuthenticated: false });
        window.location.href = '/';
      },

      updateUser: (updates) => set((state) => ({
        user: { ...state.user, ...updates },
      })),
    }),
    {
      name: 'kb-auth',
      partialize: (state) => ({ user: state.user, token: state.token, isAuthenticated: state.isAuthenticated }),
    }
  )
);

// ─── Wallet Store ─────────────────────────────────────────────────────────────

export const useWalletStore = create((set) => ({
  balance: 0,
  bonusBalance: 0,
  available: 0,
  currency: 'MWK',
  loading: false,

  setWallet: (data) => set({
    balance: data.balance || 0,
    bonusBalance: data.bonus_balance || 0,
    available: data.available || 0,
    currency: data.currency || 'MWK',
  }),

  setLoading: (loading) => set({ loading }),
}));

// ─── Bet Slip Store ───────────────────────────────────────────────────────────

export const useBetSlipStore = create((set, get) => ({
  selections: [],       // { market_id, event_id, selection, odds, home, away, market_type }
  stake: '',
  useBonus: false,
  isLive: false,

  addSelection: (sel) => {
    const { selections } = get();
    // Remove if already selected (toggle)
    const exists = selections.find(s => s.market_id === sel.market_id && s.selection === sel.selection);
    if (exists) {
      return set({ selections: selections.filter(s => !(s.market_id === sel.market_id && s.selection === sel.selection)) });
    }
    // Replace selection for same market
    const sameMarket = selections.filter(s => s.market_id !== sel.market_id);
    set({ selections: [...sameMarket, sel] });
  },

  removeSelection: (marketId, selection) => set((state) => ({
    selections: state.selections.filter(s => !(s.market_id === marketId && s.selection === selection)),
  })),

  clearSlip: () => set({ selections: [], stake: '' }),

  setStake: (stake) => set({ stake }),
  setUseBonus: (useBonus) => set({ useBonus }),
  setIsLive: (isLive) => set({ isLive }),

  getTotalOdds: () => {
    const { selections } = get();
    if (selections.length === 0) return 0;
    return selections.reduce((acc, s) => acc * parseFloat(s.odds), 1);
  },

  getPotentialWin: () => {
    const { selections, stake } = get();
    if (!stake || selections.length === 0) return 0;
    const totalOdds = selections.reduce((acc, s) => acc * parseFloat(s.odds), 1);
    const gross = parseFloat(stake) * totalOdds;
    return gross * 0.8; // After 20% tax
  },
}));

// ─── Odds Store (live updates) ────────────────────────────────────────────────

export const useOddsStore = create((set, get) => ({
  events: [],
  connected: false,
  lastUpdate: null,

  setEvents: (events) => set({ events, lastUpdate: Date.now() }),
  setConnected: (connected) => set({ connected }),

  updateOdds: (updates) => {
    const { events } = get();
    const updated = events.map(event => {
      const upd = updates.find(u => u.event_id === event.id);
      if (!upd) return event;
      return { ...event, markets: upd.markets };
    });
    set({ events: updated });
  },
}));
