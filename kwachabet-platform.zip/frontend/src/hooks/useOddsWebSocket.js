/**
 * useOddsWebSocket - connects to live odds WS feed
 * Reconnects automatically on disconnect
 */

import { useEffect, useRef, useCallback } from 'react';
import { useOddsStore } from '../store';

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'wss://api.kwachabet.mw/ws/odds';

export function useOddsWebSocket() {
  const wsRef = useRef(null);
  const reconnectTimer = useRef(null);
  const { setEvents, setConnected } = useOddsStore();

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const ws = new WebSocket(WS_URL);
    wsRef.current = ws;

    ws.onopen = () => {
      setConnected(true);
      clearTimeout(reconnectTimer.current);
    };

    ws.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data);
        if (data.type === 'odds_update') {
          setEvents(data.events || []);
        }
      } catch {}
    };

    ws.onclose = () => {
      setConnected(false);
      // Reconnect after 5 seconds
      reconnectTimer.current = setTimeout(connect, 5000);
    };

    ws.onerror = () => ws.close();
  }, [setEvents, setConnected]);

  useEffect(() => {
    connect();
    return () => {
      clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
    };
  }, [connect]);

  const subscribe = useCallback((sport) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'subscribe_sport', sport }));
    }
  }, []);

  return { subscribe };
}
