/**
 * Registration Page - Multi-step: Details → OTP verification
 */

import { useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { authAPI, walletAPI } from '../utils/api';
import { useAuthStore, useWalletStore } from '../store';
import toast from 'react-hot-toast';

const STEPS = { DETAILS: 1, OTP: 2, PIN: 3 };

export default function RegisterPage() {
  const router = useRouter();
  const { login } = useAuthStore();
  const { setWallet } = useWalletStore();

  const [step, setStep] = useState(STEPS.DETAILS);
  const [loading, setLoading] = useState(false);
  const [otp, setOtp] = useState(['', '', '', '', '', '']);

  const [form, setForm] = useState({
    phone: '+265',
    full_name: '',
    date_of_birth: '',
    email: '',
    password: '',
    confirm_password: '',
    referral_code: router.query.ref || '',
    age_confirmed: false,
    terms_confirmed: false,
  });

  function handleChange(e) {
    const { name, value, type, checked } = e.target;
    setForm(f => ({ ...f, [name]: type === 'checkbox' ? checked : value }));
  }

  function handleOtpChange(val, idx) {
    const newOtp = [...otp];
    newOtp[idx] = val.slice(-1);
    setOtp(newOtp);
    if (val && idx < 5) document.getElementById(`otp-${idx + 1}`)?.focus();
  }

  async function handleDetails(e) {
    e.preventDefault();
    if (form.password !== form.confirm_password) {
      return toast.error('Passwords do not match');
    }
    if (!form.age_confirmed) return toast.error('You must confirm you are 18+');
    if (!form.terms_confirmed) return toast.error('You must accept the terms');

    setLoading(true);
    try {
      await authAPI.initiateRegister({
        phone: form.phone,
        full_name: form.full_name.trim(),
        date_of_birth: form.date_of_birth,
        email: form.email || undefined,
        password: form.password,
      });
      toast.success('OTP sent to your phone!');
      setStep(STEPS.OTP);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleVerify(e) {
    e.preventDefault();
    const code = otp.join('');
    if (code.length !== 6) return toast.error('Enter the 6-digit OTP');

    setLoading(true);
    try {
      const res = await authAPI.verifyRegister({
        phone: form.phone,
        otp: code,
        referral_code: form.referral_code || undefined,
      });

      login(res.data.user, res.data.token);
      const walletRes = await walletAPI.getBalance();
      setWallet(walletRes.data);

      toast.success('Welcome to Kwacha Bet! 🎉');
      router.push('/');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Head>
        <title>Join Kwacha Bet — Register Free</title>
      </Head>

      <div className="min-h-screen bg-dark flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-brand rounded-xl flex items-center justify-center">
                <span className="text-black font-black text-lg">K</span>
              </div>
              <span className="text-white font-black text-2xl">Kwacha<span className="text-brand">Bet</span></span>
            </div>
            <p className="text-gray-400 text-sm">Join 50,000+ Malawian bettors</p>
          </div>

          <div className="card p-6">
            {/* Step indicator */}
            <div className="flex items-center gap-2 mb-6">
              {[1, 2].map(s => (
                <div key={s} className={`flex-1 h-1 rounded-full transition-all ${step >= s ? 'bg-brand' : 'bg-dark-border'}`} />
              ))}
            </div>

            {step === STEPS.DETAILS && (
              <form onSubmit={handleDetails} className="space-y-4">
                <h2 className="text-white font-bold text-xl mb-4">Create Your Account</h2>

                <div>
                  <label className="text-xs text-gray-400 block mb-1">Full Name</label>
                  <input name="full_name" value={form.full_name} onChange={handleChange}
                    required placeholder="Your full name" className="input" />
                </div>

                <div>
                  <label className="text-xs text-gray-400 block mb-1">Malawian Phone Number</label>
                  <input name="phone" value={form.phone} onChange={handleChange}
                    required placeholder="+265XXXXXXXXX" className="input font-mono"
                    pattern="^\+265[89]\d{8}$" />
                  <p className="text-xs text-gray-600 mt-1">Airtel (+2659) or TNM (+2658)</p>
                </div>

                <div>
                  <label className="text-xs text-gray-400 block mb-1">Date of Birth</label>
                  <input type="date" name="date_of_birth" value={form.date_of_birth} onChange={handleChange}
                    required max={new Date(Date.now() - 18 * 365.25 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}
                    className="input" />
                  <p className="text-xs text-gray-600 mt-1">Must be 18 years or older</p>
                </div>

                <div>
                  <label className="text-xs text-gray-400 block mb-1">Email (Optional)</label>
                  <input type="email" name="email" value={form.email} onChange={handleChange}
                    placeholder="your@email.com" className="input" />
                </div>

                <div>
                  <label className="text-xs text-gray-400 block mb-1">Password</label>
                  <input type="password" name="password" value={form.password} onChange={handleChange}
                    required minLength={8} placeholder="Minimum 8 characters" className="input" />
                </div>

                <div>
                  <label className="text-xs text-gray-400 block mb-1">Confirm Password</label>
                  <input type="password" name="confirm_password" value={form.confirm_password} onChange={handleChange}
                    required placeholder="Confirm your password" className="input" />
                </div>

                <div>
                  <label className="text-xs text-gray-400 block mb-1">Referral Code (Optional)</label>
                  <input name="referral_code" value={form.referral_code} onChange={handleChange}
                    placeholder="Enter referral code" className="input" />
                </div>

                <div className="space-y-2 pt-2">
                  <label className="flex items-start gap-2 cursor-pointer">
                    <input type="checkbox" name="age_confirmed" checked={form.age_confirmed}
                      onChange={handleChange} className="mt-0.5 accent-brand" />
                    <span className="text-xs text-gray-400">
                      I confirm I am 18 years of age or older and located in Malawi.
                    </span>
                  </label>
                  <label className="flex items-start gap-2 cursor-pointer">
                    <input type="checkbox" name="terms_confirmed" checked={form.terms_confirmed}
                      onChange={handleChange} className="mt-0.5 accent-brand" />
                    <span className="text-xs text-gray-400">
                      I agree to the{' '}
                      <Link href="/terms" className="text-brand hover:underline">Terms & Conditions</Link>
                      {' '}and{' '}
                      <Link href="/privacy" className="text-brand hover:underline">Privacy Policy</Link>.
                    </span>
                  </label>
                </div>

                <button type="submit" disabled={loading} className="btn-primary w-full mt-2">
                  {loading ? 'Sending OTP...' : 'Continue'}
                </button>

                <p className="text-center text-sm text-gray-500">
                  Already have an account?{' '}
                  <Link href="/login" className="text-brand hover:underline">Login</Link>
                </p>
              </form>
            )}

            {step === STEPS.OTP && (
              <form onSubmit={handleVerify} className="space-y-6">
                <div>
                  <h2 className="text-white font-bold text-xl mb-1">Verify Your Phone</h2>
                  <p className="text-gray-400 text-sm">
                    Enter the 6-digit OTP sent to <strong className="text-white">{form.phone}</strong>
                  </p>
                </div>

                {/* OTP Input Grid */}
                <div className="flex gap-2 justify-center">
                  {otp.map((digit, idx) => (
                    <input
                      key={idx}
                      id={`otp-${idx}`}
                      type="tel"
                      maxLength={1}
                      value={digit}
                      onChange={e => handleOtpChange(e.target.value, idx)}
                      onKeyDown={e => {
                        if (e.key === 'Backspace' && !digit && idx > 0) {
                          document.getElementById(`otp-${idx - 1}`)?.focus();
                        }
                      }}
                      className="w-12 h-14 text-center text-xl font-bold input"
                    />
                  ))}
                </div>

                <button type="submit" disabled={loading || otp.join('').length < 6} className="btn-primary w-full">
                  {loading ? 'Verifying...' : 'Verify & Create Account'}
                </button>

                <div className="text-center">
                  <button type="button" onClick={() => setStep(STEPS.DETAILS)} className="text-sm text-gray-400 hover:text-white">
                    ← Back
                  </button>
                  <span className="mx-3 text-dark-border">|</span>
                  <button type="button" onClick={handleDetails} className="text-sm text-brand hover:underline">
                    Resend OTP
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Welcome bonus banner */}
          <div className="mt-4 card p-4 border-brand/30 bg-brand/5">
            <p className="text-center text-sm text-white">
              🎁 <strong className="text-brand">100% Welcome Bonus</strong> up to MWK 50,000 on your first deposit!
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
