/**
 * Wallet Page - Balance, Deposit, Withdraw, Transactions
 */

import { useState, useEffect } from 'react';
import Head from 'next/head';
import { walletAPI, authAPI } from '../utils/api';
import { useAuthStore, useWalletStore } from '../store';
import Navbar from '../components/common/Navbar';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

const PAYMENT_METHODS = [
  { id: 'airtel', label: 'Airtel Money', color: 'text-red-400' },
  { id: 'mpamba', label: 'TNM Mpamba',   color: 'text-blue-400' },
  { id: 'bank',   label: 'Bank Transfer', color: 'text-gray-300' },
];

function formatMWK(n) {
  return `MWK ${parseFloat(n || 0).toLocaleString('en-MW', { minimumFractionDigits: 2 })}`;
}

const TX_TYPE_LABELS = {
  deposit: { label: 'Deposit', color: 'text-green-400' },
  withdrawal: { label: 'Withdrawal', color: 'text-red-400' },
  bet_stake: { label: 'Bet Placed', color: 'text-yellow-400' },
  bet_win: { label: 'Win', color: 'text-brand' },
  bet_refund: { label: 'Refund', color: 'text-blue-400' },
  bonus_credit: { label: 'Bonus', color: 'text-purple-400' },
  referral_bonus: { label: 'Referral', color: 'text-teal-400' },
};

export default function WalletPage() {
  const { isAuthenticated } = useAuthStore();
  const { balance, bonusBalance, available, setWallet } = useWalletStore();

  const [activeTab, setActiveTab] = useState('overview');
  const [transactions, setTransactions] = useState([]);
  const [txLoading, setTxLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // Deposit state
  const [depositAmount, setDepositAmount] = useState('');
  const [depositMethod, setDepositMethod] = useState('airtel');
  const [depositPhone, setDepositPhone] = useState('');
  const [depositLoading, setDepositLoading] = useState(false);

  // Withdrawal state
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState('airtel');
  const [withdrawDest, setWithdrawDest] = useState('');
  const [withdrawOTP, setWithdrawOTP] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [withdrawLoading, setWithdrawLoading] = useState(false);
  const [pinToken, setPinToken] = useState('');
  const [pinInput, setPinInput] = useState('');
  const [pinVerified, setPinVerified] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      walletAPI.getBalance().then(r => setWallet(r.data)).catch(() => {});
      loadTransactions();
    }
  }, [isAuthenticated, page]);

  async function loadTransactions() {
    setTxLoading(true);
    try {
      const res = await walletAPI.getTransactions({ page, limit: 15 });
      setTransactions(res.data.transactions);
      setTotalPages(res.data.pagination.pages);
    } catch { toast.error('Could not load transactions'); }
    finally { setTxLoading(false); }
  }

  async function handleDeposit(e) {
    e.preventDefault();
    if (!depositAmount || parseFloat(depositAmount) < 500) return toast.error('Minimum deposit is MWK 500');
    setDepositLoading(true);
    try {
      const res = await walletAPI.deposit({
        amount: parseFloat(depositAmount),
        method: depositMethod,
        phone: depositPhone || undefined,
      });
      if (res.data.checkout_url) {
        window.location.href = res.data.checkout_url;
      } else {
        toast.success(res.data.message);
      }
    } catch (err) { toast.error(err.message); }
    finally { setDepositLoading(false); }
  }

  async function verifyPin(e) {
    e.preventDefault();
    try {
      const res = await authAPI.verifyPin({ pin: pinInput });
      setPinToken(res.data.pin_token);
      setPinVerified(true);
      toast.success('PIN verified');
    } catch (err) { toast.error('Incorrect PIN'); }
  }

  async function sendWithdrawOTP() {
    try {
      await authAPI.requestOTP();
      setOtpSent(true);
      toast.success('OTP sent to your phone');
    } catch (err) { toast.error(err.message); }
  }

  async function handleWithdraw(e) {
    e.preventDefault();
    if (!withdrawAmount || parseFloat(withdrawAmount) < 500) return toast.error('Minimum withdrawal is MWK 500');
    if (parseFloat(withdrawAmount) > available) return toast.error('Insufficient balance');
    setWithdrawLoading(true);
    try {
      const res = await walletAPI.withdraw({
        amount: parseFloat(withdrawAmount),
        method: withdrawMethod,
        destination: withdrawDest,
        otp: withdrawOTP,
      }, { headers: { 'X-Pin-Token': pinToken } });
      toast.success(res.data.message);
      setWithdrawAmount('');
      setWithdrawOTP('');
      setOtpSent(false);
      walletAPI.getBalance().then(r => setWallet(r.data));
    } catch (err) { toast.error(err.message); }
    finally { setWithdrawLoading(false); }
  }

  const TABS = [
    { id: 'overview',  label: 'Overview' },
    { id: 'deposit',   label: 'Deposit' },
    { id: 'withdraw',  label: 'Withdraw' },
    { id: 'history',   label: 'History' },
  ];

  return (
    <>
      <Head><title>My Wallet — Kwacha Bet</title></Head>
      <div className="min-h-screen bg-dark">
        <Navbar />
        <div className="max-w-2xl mx-auto px-4 py-8">
          {/* Balance cards */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <div className="card p-4">
              <p className="text-xs text-gray-500 mb-1">Real Balance</p>
              <p className="text-xl font-bold text-white">{formatMWK(balance)}</p>
              <p className="text-xs text-gray-600 mt-1">Available: {formatMWK(available)}</p>
            </div>
            {bonusBalance > 0 && (
              <div className="card p-4 border-brand/20 bg-brand/5">
                <p className="text-xs text-brand/70 mb-1">Bonus Balance</p>
                <p className="text-xl font-bold text-brand">{formatMWK(bonusBalance)}</p>
                <p className="text-xs text-gray-600 mt-1">Wagering required</p>
              </div>
            )}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-dark-surface rounded-lg p-1 mb-6">
            {TABS.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all
                  ${activeTab === tab.id ? 'bg-brand text-black' : 'text-gray-400 hover:text-white'}`}>
                {tab.label}
              </button>
            ))}
          </div>

          {/* Deposit */}
          {activeTab === 'deposit' && (
            <form onSubmit={handleDeposit} className="card p-5 space-y-4">
              <h3 className="text-white font-bold">Add Funds</h3>
              <div>
                <label className="text-xs text-gray-400 block mb-2">Payment Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {PAYMENT_METHODS.map(m => (
                    <button key={m.id} type="button" onClick={() => setDepositMethod(m.id)}
                      className={`p-3 rounded-lg border text-sm font-medium transition-all
                        ${depositMethod === m.id ? 'border-brand bg-brand/10 text-brand' : 'border-dark-border text-gray-400 hover:border-gray-500'}`}>
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-gray-400 block mb-1">Amount (MWK)</label>
                <input type="number" value={depositAmount} onChange={e => setDepositAmount(e.target.value)}
                  placeholder="Min. MWK 500" min="500" required className="input" />
                <div className="flex gap-2 mt-2">
                  {[1000,2000,5000,10000].map(a => (
                    <button key={a} type="button" onClick={() => setDepositAmount(a.toString())}
                      className="text-xs px-2 py-1 bg-dark-surface border border-dark-border rounded hover:border-brand text-gray-400 hover:text-brand transition-colors">
                      {a.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {depositMethod !== 'bank' && (
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Mobile Money Number</label>
                  <input value={depositPhone} onChange={e => setDepositPhone(e.target.value)}
                    placeholder="+265XXXXXXXXX" className="input" />
                </div>
              )}

              <button type="submit" disabled={depositLoading} className="btn-primary w-full">
                {depositLoading ? 'Processing...' : `Deposit ${depositAmount ? formatMWK(depositAmount) : ''}`}
              </button>
              <p className="text-xs text-gray-600 text-center">Instant credit • Secure • Encrypted</p>
            </form>
          )}

          {/* Withdraw */}
          {activeTab === 'withdraw' && (
            <div className="space-y-4">
              {!pinVerified ? (
                <form onSubmit={verifyPin} className="card p-5 space-y-4">
                  <h3 className="text-white font-bold">Verify PIN</h3>
                  <p className="text-gray-400 text-sm">Enter your 4-digit transaction PIN to continue.</p>
                  <div className="flex gap-2 justify-center">
                    {[0,1,2,3].map(i => (
                      <input key={i} type="password" maxLength={1}
                        value={pinInput[i] || ''}
                        onChange={e => {
                          const p = pinInput.split('');
                          p[i] = e.target.value.slice(-1);
                          setPinInput(p.join(''));
                          if (e.target.value && i < 3) document.getElementById(`pin-${i+1}`)?.focus();
                        }}
                        id={`pin-${i}`}
                        className="w-12 h-14 text-center text-xl font-bold input" />
                    ))}
                  </div>
                  <button type="submit" className="btn-primary w-full">Verify PIN</button>
                  <p className="text-xs text-center text-gray-500">
                    Haven't set a PIN yet?{' '}
                    <a href="/profile" className="text-brand hover:underline">Set PIN in Profile</a>
                  </p>
                </form>
              ) : (
                <form onSubmit={handleWithdraw} className="card p-5 space-y-4">
                  <h3 className="text-white font-bold">Withdraw Funds</h3>
                  <div>
                    <label className="text-xs text-gray-400 block mb-2">Withdrawal Method</label>
                    <div className="grid grid-cols-2 gap-2">
                      {PAYMENT_METHODS.slice(0,2).map(m => (
                        <button key={m.id} type="button" onClick={() => setWithdrawMethod(m.id)}
                          className={`p-3 rounded-lg border text-sm font-medium transition-all
                            ${withdrawMethod === m.id ? 'border-brand bg-brand/10 text-brand' : 'border-dark-border text-gray-400'}`}>
                          {m.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Amount (MWK)</label>
                    <input type="number" value={withdrawAmount} onChange={e => setWithdrawAmount(e.target.value)}
                      placeholder={`Min MWK 500 • Max ${formatMWK(available)}`} min="500" required className="input" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">Mobile Money Number</label>
                    <input value={withdrawDest} onChange={e => setWithdrawDest(e.target.value)}
                      placeholder="+265XXXXXXXXX" required className="input" />
                  </div>
                  {!otpSent ? (
                    <button type="button" onClick={sendWithdrawOTP} className="btn-secondary w-full">
                      Send OTP to Verify
                    </button>
                  ) : (
                    <div>
                      <label className="text-xs text-gray-400 block mb-1">Enter OTP</label>
                      <input value={withdrawOTP} onChange={e => setWithdrawOTP(e.target.value)}
                        placeholder="6-digit OTP" maxLength={6} required className="input" />
                    </div>
                  )}
                  {otpSent && (
                    <button type="submit" disabled={withdrawLoading} className="btn-primary w-full">
                      {withdrawLoading ? 'Processing...' : `Withdraw ${withdrawAmount ? formatMWK(withdrawAmount) : ''}`}
                    </button>
                  )}
                </form>
              )}
            </div>
          )}

          {/* Transaction History */}
          {(activeTab === 'history' || activeTab === 'overview') && (
            <div className="card">
              <div className="px-4 py-3 border-b border-dark-border">
                <h3 className="text-white font-semibold">Transaction History</h3>
              </div>
              {txLoading ? (
                <div className="p-8 text-center text-gray-500">Loading...</div>
              ) : transactions.length === 0 ? (
                <div className="p-8 text-center text-gray-500">No transactions yet.</div>
              ) : (
                <div className="divide-y divide-dark-border">
                  {transactions.map(tx => {
                    const meta = TX_TYPE_LABELS[tx.type] || { label: tx.type, color: 'text-gray-300' };
                    const isCredit = tx.amount > 0;
                    return (
                      <div key={tx.id} className="flex items-center justify-between px-4 py-3">
                        <div>
                          <p className={`text-sm font-medium ${meta.color}`}>{meta.label}</p>
                          <p className="text-xs text-gray-500">{format(new Date(tx.created_at), 'dd MMM yyyy HH:mm')}</p>
                          {tx.reference && <p className="text-xs text-gray-600 font-mono">{tx.reference}</p>}
                        </div>
                        <div className="text-right">
                          <p className={`font-bold ${isCredit ? 'text-green-400' : 'text-red-400'}`}>
                            {isCredit ? '+' : ''}{formatMWK(Math.abs(tx.amount))}
                          </p>
                          <p className="text-xs text-gray-500">{formatMWK(tx.balance_after)}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              {totalPages > 1 && (
                <div className="flex justify-center gap-3 p-4">
                  <button disabled={page === 1} onClick={() => setPage(p => p-1)} className="btn-secondary text-xs py-1.5 px-3 disabled:opacity-30">← Prev</button>
                  <span className="text-gray-400 text-sm flex items-center">{page}/{totalPages}</span>
                  <button disabled={page === totalPages} onClick={() => setPage(p => p+1)} className="btn-secondary text-xs py-1.5 px-3 disabled:opacity-30">Next →</button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
