/**
 * Login Page
 */

import { useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { authAPI, walletAPI } from '../utils/api';
import { useAuthStore, useWalletStore } from '../store';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuthStore();
  const { setWallet } = useWalletStore();
  const [form, setForm] = useState({ phone: '+265', password: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  async function handleLogin(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authAPI.login(form);
      login(res.data.user, res.data.token);
      const walletRes = await walletAPI.getBalance();
      setWallet(walletRes.data);
      toast.success(`Welcome back, ${res.data.user.full_name.split(' ')[0]}!`);
      router.push(router.query.redirect || '/');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Head><title>Login — Kwacha Bet</title></Head>
      <div className="min-h-screen bg-dark flex items-center justify-center px-4">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8">
            <Link href="/" className="inline-flex items-center gap-2">
              <div className="w-10 h-10 bg-brand rounded-xl flex items-center justify-center">
                <span className="text-black font-black text-lg">K</span>
              </div>
              <span className="text-white font-black text-2xl">Kwacha<span className="text-brand">Bet</span></span>
            </Link>
          </div>
          <div className="card p-6">
            <h2 className="text-white font-bold text-xl mb-6">Welcome Back</h2>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-xs text-gray-400 block mb-1">Phone Number</label>
                <input name="phone" value={form.phone} onChange={handleChange}
                  placeholder="+265XXXXXXXXX" required className="input font-mono" />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Password</label>
                <input type="password" name="password" value={form.password} onChange={handleChange}
                  placeholder="Your password" required className="input" />
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full mt-2">
                {loading ? 'Logging in...' : 'Login'}
              </button>
            </form>
            <div className="mt-4 text-center text-sm text-gray-500">
              Don't have an account?{' '}
              <Link href="/register" className="text-brand hover:underline">Join Now</Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
