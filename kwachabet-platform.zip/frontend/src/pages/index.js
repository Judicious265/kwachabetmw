/**
 * Kwacha Bet - Homepage
 * Features: live ticker, sport tabs, event cards with odds, bet slip sidebar
 */

import { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useOddsStore, useBetSlipStore, useAuthStore } from '../store';
import { useOddsWebSocket } from '../hooks/useOddsWebSocket';
import { oddsAPI } from '../utils/api';
import Navbar from '../components/common/Navbar';
import BetSlip from '../components/betting/BetSlip';
import EventCard from '../components/betting/EventCard';
import SportsTabs from '../components/betting/SportsTabs';
import LiveTicker from '../components/common/LiveTicker';
import toast from 'react-hot-toast';

const SPORTS = [
  { id: 'all',         label: 'All',          icon: '⚽' },
  { id: 'football',    label: 'Football',     icon: '⚽' },
  { id: 'basketball',  label: 'Basketball',   icon: '🏀' },
  { id: 'tennis',      label: 'Tennis',       icon: '🎾' },
  { id: 'ice_hockey',  label: 'Ice Hockey',   icon: '🏒' },
  { id: 'baseball',    label: 'Baseball',     icon: '⚾' },
  { id: 'rugby_league',label: 'Rugby',        icon: '🏉' },
];

export default function HomePage() {
  const [activeSport, setActiveSport] = useState('all');
  const [liveOnly, setLiveOnly] = useState(false);
  const [loading, setLoading] = useState(true);

  const { events, setEvents, connected } = useOddsStore();
  const { selections } = useBetSlipStore();
  const { subscribe } = useOddsWebSocket();

  useEffect(() => {
    loadEvents();
  }, [activeSport, liveOnly]);

  useEffect(() => {
    if (activeSport !== 'all') subscribe(activeSport);
  }, [activeSport, subscribe]);

  async function loadEvents() {
    setLoading(true);
    try {
      const params = {};
      if (activeSport !== 'all') params.sport = activeSport;
      if (liveOnly) params.status = 'live';
      else params.status = 'upcoming';

      const res = await oddsAPI.getEvents(params);
      setEvents(res.data.events || []);
    } catch (err) {
      toast.error('Could not load events');
    } finally {
      setLoading(false);
    }
  }

  const filteredEvents = activeSport === 'all'
    ? events
    : events.filter(e => e.sport_id === activeSport);

  return (
    <>
      <Head>
        <title>Kwacha Bet — Malawi's Premier Betting Platform</title>
        <meta name="description" content="Bet on football, basketball, tennis and more. Fast deposits via Airtel Money and TNM Mpamba." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen bg-dark text-white">
        <Navbar />
        <LiveTicker events={events} />

        {/* Hero Banner */}
        <div className="relative overflow-hidden bg-gradient-to-r from-dark-surface to-dark-card border-b border-dark-border">
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h1 className="text-3xl md:text-4xl font-black text-white mb-2">
                  Bet Smarter. <span className="text-brand">Win More.</span>
                </h1>
                <p className="text-gray-400 text-lg">
                  Malawi's #1 betting platform — Pay with Airtel Money & TNM Mpamba
                </p>
                <div className="flex items-center gap-3 mt-4">
                  <div className={`flex items-center gap-1.5 text-xs ${connected ? 'text-brand' : 'text-gray-500'}`}>
                    <span className={`w-2 h-2 rounded-full ${connected ? 'bg-brand animate-pulse' : 'bg-gray-500'}`} />
                    {connected ? 'Live odds updating' : 'Connecting...'}
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <Link href="/register" className="btn-primary text-sm">
                  Join Now — Get 100% Bonus
                </Link>
                <Link href="/deposit" className="btn-secondary text-sm">
                  Deposit
                </Link>
              </div>
            </div>
          </div>
          {/* Decorative green glow */}
          <div className="absolute -right-20 -top-20 w-64 h-64 bg-brand/5 rounded-full blur-3xl pointer-events-none" />
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex gap-6">

            {/* Events Column */}
            <div className="flex-1 min-w-0">
              {/* Sport Tabs */}
              <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-2 scrollbar-hide">
                {SPORTS.map(sport => (
                  <button
                    key={sport.id}
                    onClick={() => setActiveSport(sport.id)}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all
                      ${activeSport === sport.id
                        ? 'bg-brand text-black'
                        : 'bg-dark-card border border-dark-border text-gray-300 hover:border-brand hover:text-white'
                      }`}
                  >
                    <span>{sport.icon}</span>
                    {sport.label}
                  </button>
                ))}

                <button
                  onClick={() => setLiveOnly(!liveOnly)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ml-auto
                    ${liveOnly ? 'bg-red-600 text-white' : 'bg-dark-card border border-dark-border text-gray-300 hover:border-red-500'}`}
                >
                  <span className={`w-2 h-2 rounded-full bg-red-400 ${liveOnly ? 'animate-pulse' : ''}`} />
                  LIVE
                </button>
              </div>

              {/* Events List */}
              {loading ? (
                <div className="space-y-3">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="card p-4 animate-pulse">
                      <div className="flex justify-between">
                        <div className="h-4 bg-dark-border rounded w-48" />
                        <div className="h-4 bg-dark-border rounded w-16" />
                      </div>
                      <div className="flex gap-2 mt-3">
                        {[1,2,3].map(j => <div key={j} className="h-10 bg-dark-border rounded flex-1" />)}
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredEvents.length === 0 ? (
                <div className="card p-12 text-center text-gray-500">
                  <p className="text-4xl mb-3">⚽</p>
                  <p className="text-lg">No events available for this sport right now.</p>
                  <p className="text-sm mt-1">Check back soon or select another sport.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredEvents.map(event => (
                    <EventCard key={event.id} event={event} />
                  ))}
                </div>
              )}
            </div>

            {/* Bet Slip Sidebar */}
            <div className="hidden lg:block w-80 flex-shrink-0">
              <BetSlip />
            </div>
          </div>
        </div>

        {/* Mobile Bet Slip FAB */}
        {selections.length > 0 && (
          <div className="fixed bottom-4 left-4 right-4 lg:hidden z-50">
            <Link
              href="/betslip"
              className="block w-full btn-primary text-center text-base py-4 shadow-lg shadow-brand/20"
            >
              View Bet Slip ({selections.length} selection{selections.length > 1 ? 's' : ''}) →
            </Link>
          </div>
        )}
      </div>
    </>
  );
}
