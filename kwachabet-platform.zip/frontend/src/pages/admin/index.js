/**
 * Admin Dashboard - Full management panel
 * Users, tickets, financials, fraud, bonus management
 */

import { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { adminAPI } from '../../utils/api';
import { useAuthStore } from '../../store';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

function StatCard({ label, value, sub, color = 'text-white' }) {
  return (
    <div className="bg-dark-card border border-dark-border rounded-xl p-4">
      <p className="text-xs text-gray-500 mb-1">{label}</p>
      <p className={`text-2xl font-black ${color}`}>{value}</p>
      {sub && <p className="text-xs text-gray-600 mt-1">{sub}</p>}
    </div>
  );
}

function formatMWK(n) {
  return `MWK ${parseFloat(n || 0).toLocaleString('en-MW', { minimumFractionDigits: 2 })}`;
}

const ADMIN_TABS = [
  { id: 'dashboard',   label: '📊 Dashboard' },
  { id: 'users',       label: '👥 Users' },
  { id: 'tickets',     label: '🎯 Tickets' },
  { id: 'withdrawals', label: '💸 Withdrawals' },
  { id: 'fraud',       label: '🔴 Fraud' },
  { id: 'bonus',       label: '🎁 Bonus' },
];

export default function AdminDashboard() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();
  const [tab, setTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [fraudFlags, setFraudFlags] = useState([]);
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!isAuthenticated || !user?.is_admin) {
      router.push('/');
      return;
    }
    loadTab(tab);
  }, [tab, isAuthenticated]);

  async function loadTab(t) {
    setLoading(true);
    try {
      if (t === 'dashboard') {
        const r = await adminAPI.getDashboard();
        setStats(r.data);
      } else if (t === 'users') {
        const r = await adminAPI.getUsers({ limit: 30 });
        setUsers(r.data.users);
      } else if (t === 'tickets') {
        const r = await adminAPI.getTickets({ limit: 30 });
        setTickets(r.data.tickets);
      } else if (t === 'withdrawals') {
        const r = await adminAPI.getPendingWithdrawals();
        setWithdrawals(r.data.withdrawals);
      } else if (t === 'fraud') {
        const r = await adminAPI.getFraudDashboard();
        setFraudFlags(r.data.flags?.rows || []);
      } else if (t === 'bonus') {
        const r = await adminAPI.getCampaigns();
        setCampaigns(r.data.campaigns);
      }
    } catch (err) {
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  }

  async function handleSuspend(userId, suspended) {
    try {
      if (suspended) {
        await adminAPI.unsuspendUser(userId);
        toast.success('User unsuspended');
      } else {
        const reason = prompt('Reason for suspension:');
        if (!reason) return;
        await adminAPI.suspendUser(userId, reason);
        toast.success('User suspended');
      }
      loadTab('users');
    } catch { toast.error('Action failed'); }
  }

  async function handleWithdrawal(id, approve) {
    try {
      if (approve) {
        await adminAPI.approveWithdrawal(id);
        toast.success('Withdrawal approved and processing');
      } else {
        const reason = prompt('Reason for rejection:');
        if (!reason) return;
        await adminAPI.rejectWithdrawal(id, reason);
        toast.success('Withdrawal rejected');
      }
      loadTab('withdrawals');
    } catch { toast.error('Action failed'); }
  }

  async function handleResolveFlag(id) {
    const notes = prompt('Resolution notes:');
    if (notes === null) return;
    try {
      await adminAPI.resolveFraudFlag(id, notes);
      toast.success('Flag resolved');
      loadTab('fraud');
    } catch { toast.error('Failed to resolve flag'); }
  }

  const SEVERITY_COLORS = {
    low: 'text-gray-400 bg-gray-800',
    medium: 'text-yellow-400 bg-yellow-900/30',
    high: 'text-orange-400 bg-orange-900/30',
    critical: 'text-red-400 bg-red-900/30',
  };

  return (
    <>
      <Head><title>Admin Panel — Kwacha Bet</title></Head>
      <div className="min-h-screen bg-dark text-white flex">

        {/* Sidebar */}
        <aside className="w-56 bg-dark-surface border-r border-dark-border flex-shrink-0 flex flex-col">
          <div className="p-4 border-b border-dark-border">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center">
                <span className="text-black font-black text-sm">K</span>
              </div>
              <div>
                <p className="text-white font-bold text-sm">KwachaBet</p>
                <p className="text-xs text-brand">Admin Panel</p>
              </div>
            </div>
          </div>
          <nav className="flex-1 p-3 space-y-1">
            {ADMIN_TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-all
                  ${tab === t.id ? 'bg-brand/10 text-brand border border-brand/20' : 'text-gray-400 hover:text-white hover:bg-dark-hover'}`}>
                {t.label}
              </button>
            ))}
          </nav>
          <div className="p-3 border-t border-dark-border">
            <p className="text-xs text-gray-600">{user?.full_name}</p>
            <p className="text-xs text-gray-700">{user?.phone}</p>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-auto">
          <div className="p-6">

            {/* ── Dashboard Tab ── */}
            {tab === 'dashboard' && (
              <div className="space-y-6">
                <h1 className="text-2xl font-black text-white">Dashboard</h1>
                {loading ? (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[...Array(8)].map((_, i) => (
                      <div key={i} className="bg-dark-card border border-dark-border rounded-xl p-4 animate-pulse">
                        <div className="h-3 bg-dark-border rounded w-20 mb-2" />
                        <div className="h-7 bg-dark-border rounded w-28" />
                      </div>
                    ))}
                  </div>
                ) : stats && (
                  <>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <StatCard label="Total Users" value={stats.users?.total?.toLocaleString()} sub={`+${stats.users?.new_today} today`} color="text-brand" />
                      <StatCard label="Active Tickets" value={stats.bets?.active_tickets?.toLocaleString()} color="text-yellow-400" />
                      <StatCard label="Deposits Today" value={formatMWK(stats.finance?.deposits_today)} color="text-green-400" />
                      <StatCard label="Withdrawals Today" value={formatMWK(stats.finance?.withdrawals_today)} color="text-red-400" />
                      <StatCard label="Pending Withdrawals" value={stats.finance?.pending_withdrawals} color="text-orange-400" />
                      <StatCard label="Total Wallet Balance" value={formatMWK(stats.finance?.total_wallet_balance)} color="text-white" />
                      <StatCard label="Open Fraud Flags" value={stats.fraud?.open_flags} color={stats.fraud?.open_flags > 0 ? 'text-red-400' : 'text-gray-400'} />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-dark-card border border-dark-border rounded-xl p-4">
                        <h3 className="text-sm font-semibold text-white mb-3">Quick Actions</h3>
                        <div className="space-y-2">
                          <button onClick={() => setTab('withdrawals')} className="w-full text-left px-3 py-2 rounded-lg bg-dark-surface hover:bg-dark-hover text-sm text-gray-300 transition-colors">
                            💸 Review Pending Withdrawals ({stats.finance?.pending_withdrawals})
                          </button>
                          <button onClick={() => setTab('fraud')} className="w-full text-left px-3 py-2 rounded-lg bg-dark-surface hover:bg-dark-hover text-sm text-gray-300 transition-colors">
                            🔴 Fraud Flags ({stats.fraud?.open_flags})
                          </button>
                          <button onClick={() => setTab('users')} className="w-full text-left px-3 py-2 rounded-lg bg-dark-surface hover:bg-dark-hover text-sm text-gray-300 transition-colors">
                            👥 Manage Users
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* ── Users Tab ── */}
            {tab === 'users' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h1 className="text-2xl font-black">Users</h1>
                  <input value={search} onChange={e => setSearch(e.target.value)}
                    placeholder="Search by phone or name..."
                    className="bg-dark-surface border border-dark-border rounded-lg px-4 py-2 text-sm text-white w-64 focus:outline-none focus:border-brand" />
                </div>
                <div className="bg-dark-card border border-dark-border rounded-xl overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-dark-surface border-b border-dark-border">
                      <tr>{['Phone','Name','Balance','Risk','Status','Joined','Actions'].map(h => (
                        <th key={h} className="text-left px-4 py-3 text-xs text-gray-500 font-medium">{h}</th>
                      ))}</tr>
                    </thead>
                    <tbody className="divide-y divide-dark-border">
                      {users.filter(u =>
                        !search || u.phone.includes(search) || u.full_name?.toLowerCase().includes(search.toLowerCase())
                      ).map(u => (
                        <tr key={u.id} className="hover:bg-dark-hover transition-colors">
                          <td className="px-4 py-3 font-mono text-xs text-gray-300">{u.phone}</td>
                          <td className="px-4 py-3 text-white">{u.full_name}</td>
                          <td className="px-4 py-3 text-green-400 text-xs">{formatMWK(u.wallet?.balance)}</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                              u.risk_score >= 70 ? 'bg-red-900/50 text-red-400' :
                              u.risk_score >= 40 ? 'bg-yellow-900/50 text-yellow-400' :
                              'bg-dark-surface text-gray-400'}`}>
                              {u.risk_score}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-0.5 rounded-full ${u.is_suspended ? 'bg-red-900/40 text-red-400' : 'bg-green-900/40 text-green-400'}`}>
                              {u.is_suspended ? 'Suspended' : 'Active'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-xs text-gray-500">
                            {format(new Date(u.created_at), 'dd MMM yy')}
                          </td>
                          <td className="px-4 py-3">
                            <button onClick={() => handleSuspend(u.id, u.is_suspended)}
                              className={`text-xs px-2 py-1 rounded transition-colors ${
                                u.is_suspended
                                  ? 'text-green-400 hover:bg-green-900/20'
                                  : 'text-red-400 hover:bg-red-900/20'
                              }`}>
                              {u.is_suspended ? 'Unsuspend' : 'Suspend'}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ── Tickets Tab ── */}
            {tab === 'tickets' && (
              <div className="space-y-4">
                <h1 className="text-2xl font-black">All Tickets</h1>
                <div className="bg-dark-card border border-dark-border rounded-xl overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-dark-surface border-b border-dark-border">
                      <tr>{['Code','User','Type','Stake','Odds','Potential Win','Status','Date'].map(h => (
                        <th key={h} className="text-left px-4 py-3 text-xs text-gray-500">{h}</th>
                      ))}</tr>
                    </thead>
                    <tbody className="divide-y divide-dark-border">
                      {tickets.map(t => (
                        <tr key={t.id} className={`hover:bg-dark-hover transition-colors ${t.status === 'won' ? 'border-l-2 border-brand' : ''}`}>
                          <td className="px-4 py-3 font-mono text-xs text-brand">{t.ticket_code}</td>
                          <td className="px-4 py-3 text-xs text-gray-400">{t.user?.phone}</td>
                          <td className="px-4 py-3 text-xs capitalize text-gray-300">{t.type}</td>
                          <td className="px-4 py-3 text-xs text-white">{formatMWK(t.stake)}</td>
                          <td className="px-4 py-3 text-xs font-bold text-yellow-400">{parseFloat(t.total_odds).toFixed(2)}</td>
                          <td className="px-4 py-3 text-xs text-gray-300">{formatMWK(t.potential_win)}</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-0.5 rounded-full ${
                              t.status === 'won' ? 'badge-won' :
                              t.status === 'lost' ? 'badge-lost' : 'badge-pending'}`}>
                              {t.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-xs text-gray-500">
                            {format(new Date(t.created_at), 'dd MMM HH:mm')}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ── Withdrawals Tab ── */}
            {tab === 'withdrawals' && (
              <div className="space-y-4">
                <h1 className="text-2xl font-black">Pending Withdrawals</h1>
                {withdrawals.length === 0 ? (
                  <div className="bg-dark-card border border-dark-border rounded-xl p-12 text-center text-gray-500">
                    No pending withdrawals
                  </div>
                ) : (
                  <div className="space-y-3">
                    {withdrawals.map(w => (
                      <div key={w.id} className={`bg-dark-card border rounded-xl p-4 ${
                        w.status === 'flagged' ? 'border-red-700/50 bg-red-900/5' : 'border-dark-border'
                      }`}>
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-white font-bold">{formatMWK(w.amount)}</span>
                              <span className={`text-xs px-2 py-0.5 rounded-full ${
                                w.status === 'flagged' ? 'bg-red-900/40 text-red-400' : 'bg-yellow-900/40 text-yellow-400'
                              }`}>
                                {w.status}
                              </span>
                              {w.fraud_score > 0 && (
                                <span className="text-xs text-orange-400">Risk: {w.fraud_score}/100</span>
                              )}
                            </div>
                            <p className="text-sm text-gray-400">{w.user?.full_name} — {w.user?.phone}</p>
                            <p className="text-xs text-gray-500">
                              To: {w.destination} via {w.payment_method?.toUpperCase()}
                            </p>
                            <p className="text-xs text-gray-600">
                              {format(new Date(w.created_at), 'dd MMM yyyy HH:mm')}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <button onClick={() => handleWithdrawal(w.id, true)}
                              className="px-3 py-1.5 text-xs bg-brand text-black font-bold rounded-lg hover:bg-brand-dark transition-colors">
                              Approve
                            </button>
                            <button onClick={() => handleWithdrawal(w.id, false)}
                              className="px-3 py-1.5 text-xs border border-red-700 text-red-400 rounded-lg hover:bg-red-900/20 transition-colors">
                              Reject
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ── Fraud Tab ── */}
            {tab === 'fraud' && (
              <div className="space-y-4">
                <h1 className="text-2xl font-black">Fraud Dashboard</h1>
                {fraudFlags.length === 0 ? (
                  <div className="bg-dark-card border border-dark-border rounded-xl p-12 text-center text-gray-500">
                    🎉 No active fraud flags
                  </div>
                ) : (
                  <div className="space-y-3">
                    {fraudFlags.map(flag => (
                      <div key={flag.id} className="bg-dark-card border border-dark-border rounded-xl p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className={`text-xs font-bold px-2 py-0.5 rounded ${SEVERITY_COLORS[flag.severity] || 'text-gray-400'}`}>
                                {flag.severity?.toUpperCase()}
                              </span>
                              <code className="text-xs text-gray-400 font-mono">{flag.rule_code}</code>
                            </div>
                            <p className="text-sm text-white">{flag.description}</p>
                            <p className="text-xs text-gray-400">
                              User: {flag.user?.full_name} ({flag.user?.phone}) — Risk: {flag.user?.risk_score}/100
                            </p>
                            <p className="text-xs text-gray-600">
                              {format(new Date(flag.created_at), 'dd MMM yyyy HH:mm')}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <button onClick={() => handleResolveFlag(flag.id)}
                              className="px-3 py-1.5 text-xs bg-dark-surface border border-dark-border text-gray-300 rounded-lg hover:border-brand hover:text-brand transition-colors">
                              Resolve
                            </button>
                            <button onClick={() => handleSuspend(flag.user_id, false)}
                              className="px-3 py-1.5 text-xs border border-red-700 text-red-400 rounded-lg hover:bg-red-900/20 transition-colors">
                              Suspend User
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ── Bonus Tab ── */}
            {tab === 'bonus' && (
              <div className="space-y-6">
                <h1 className="text-2xl font-black">Bonus Management</h1>

                {/* Assign Free Bet */}
                <div className="bg-dark-card border border-dark-border rounded-xl p-5">
                  <h3 className="text-white font-semibold mb-4">Assign Free Bet</h3>
                  <form onSubmit={async e => {
                    e.preventDefault();
                    const fd = new FormData(e.target);
                    try {
                      await adminAPI.assignFreeBet({
                        user_id: fd.get('user_id'),
                        amount: parseFloat(fd.get('amount')),
                        expiry_days: parseInt(fd.get('expiry_days')),
                      });
                      toast.success('Free bet assigned!');
                      e.target.reset();
                    } catch { toast.error('Failed to assign free bet'); }
                  }} className="grid grid-cols-3 gap-3">
                    <input name="user_id" required placeholder="User ID (UUID)" className="bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-brand col-span-3 md:col-span-1" />
                    <input name="amount" type="number" required min="100" placeholder="Amount (MWK)" className="bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-brand" />
                    <input name="expiry_days" type="number" required min="1" max="30" defaultValue="7" placeholder="Expiry (days)" className="bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-brand" />
                    <button type="submit" className="btn-primary text-sm col-span-3 md:col-span-1">Assign Free Bet</button>
                  </form>
                </div>

                {/* Active Campaigns */}
                <div>
                  <h3 className="text-white font-semibold mb-3">Active Campaigns</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {campaigns.map(c => (
                      <div key={c.id} className="bg-dark-card border border-dark-border rounded-xl p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-white font-semibold text-sm">{c.name}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${c.is_active ? 'bg-green-900/40 text-green-400' : 'bg-dark-surface text-gray-500'}`}>
                            {c.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500 space-y-1">
                          <p>Type: <span className="text-gray-300 capitalize">{c.type}</span></p>
                          {c.percent && <p>Bonus: <span className="text-brand">{c.percent}%</span></p>}
                          {c.max_bonus && <p>Max: <span className="text-gray-300">{formatMWK(c.max_bonus)}</span></p>}
                          <p>Wagering: <span className="text-gray-300">{c.wagering_req}x</span></p>
                          <p>Min odds: <span className="text-gray-300">{c.min_odds}</span></p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

          </div>
        </main>
      </div>
    </>
  );
}
