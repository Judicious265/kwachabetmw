/**
 * Next.js App - Global providers, toast, device fingerprinting
 */

import '../styles/globals.css';
import { Toaster } from 'react-hot-toast';
import { useEffect } from 'react';

// Simple device fingerprint (production: use FingerprintJS Pro)
function generateFingerprint() {
  const components = [
    navigator.userAgent,
    navigator.language,
    screen.width + 'x' + screen.height,
    new Date().getTimezoneOffset(),
    navigator.hardwareConcurrency,
  ].join('|');

  // Simple hash
  let hash = 0;
  for (let i = 0; i < components.length; i++) {
    hash = ((hash << 5) - hash) + components.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash).toString(36);
}

export default function App({ Component, pageProps }) {
  useEffect(() => {
    // Set device fingerprint on first load
    if (!localStorage.getItem('kb_device_fp')) {
      localStorage.setItem('kb_device_fp', generateFingerprint());
    }
  }, []);

  return (
    <>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#1C2128',
            color: '#E6EDF3',
            border: '1px solid #30363D',
            borderRadius: '12px',
            fontSize: '14px',
          },
          success: {
            iconTheme: { primary: '#00C853', secondary: '#0D1117' },
          },
          error: {
            iconTheme: { primary: '#F85149', secondary: '#0D1117' },
          },
          duration: 4000,
        }}
      />
      <Component {...pageProps} />
    </>
  );
}
