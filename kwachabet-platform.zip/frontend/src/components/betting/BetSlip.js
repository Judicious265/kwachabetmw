/**
 * BetSlip - Sidebar bet slip component
 * Handles single/accumulator bets with stake input
 */

import { useState } from 'react';
import { useBetSlipStore, useAuthStore, useWalletStore } from '../../store';
import { bettingAPI, walletAPI } from '../../utils/api';
import toast from 'react-hot-toast';
import { useRouter } from 'next/router';

function formatOdds(n) { return parseFloat(n).toFixed(2); }
function formatMWK(n) {
  return `MWK ${parseFloat(n).toLocaleString('en-MW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

const QUICK_STAKES = [500, 1000, 2000, 5000, 10000];

export default function BetSlip() {
  const router = useRouter();
  const { selections, stake, useBonus, isLive, removeSelection, clearSlip,
          setStake, setUseBonus, getTotalOdds, getPotentialWin } = useBetSlipStore();
  const { isAuthenticated } = useAuthStore();
  const { balance, bonusBalance, available } = useWalletStore();

  const [loading, setLoading] = useState(false);
  const [lastTicket, setLastTicket] = useState(null);

  const totalOdds = getTotalOdds();
  const potentialWin = getPotentialWin();
  const betType = selections.length === 1 ? 'Single' : `Accumulator (${selections.length})`;

  async function placeBet() {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }

    if (!stake || parseFloat(stake) < 50) {
      toast.error('Minimum stake is MWK 50');
      return;
    }

    if (parseFloat(stake) > available) {
      toast.error('Insufficient balance. Please deposit first.');
      return;
    }

    setLoading(true);
    try {
      const res = await bettingAPI.placeBet({
        selections: selections.map(s => ({
          market_id: s.market_id,
          selection: s.selection,
        })),
        stake: parseFloat(stake),
        use_bonus: useBonus,
        is_live: isLive,
      });

      setLastTicket(res.data.ticket);
      clearSlip();

      // Refresh balance
      const walletRes = await walletAPI.getBalance();
      useWalletStore.getState().setWallet(walletRes.data);

      toast.success(`Bet placed! Ticket: ${res.data.ticket.ticket_code}`);
    } catch (err) {
      toast.error(err.message || 'Failed to place bet. Try again.');
    } finally {
      setLoading(false);
    }
  }

  // ── Last Ticket Confirmation ──────────────────────────────────────────────
  if (lastTicket) {
    return (
      <div className="card p-5 animate-slide-up">
        <div className="text-center">
          <div className="w-14 h-14 rounded-full bg-brand/20 border border-brand flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">✓</span>
          </div>
          <h3 className="text-white font-bold text-lg mb-1">Bet Placed!</h3>
          <p className="text-gray-400 text-sm mb-4">Good luck! 🤞</p>

          <div className="bg-dark-surface rounded-lg p-4 text-left space-y-2 mb-4">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Ticket</span>
              <span className="text-brand font-mono font-bold">{lastTicket.ticket_code}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Stake</span>
              <span className="text-white">{formatMWK(lastTicket.stake)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Total Odds</span>
              <span className="text-white">{formatOdds(lastTicket.total_odds)}</span>
            </div>
            <div className="flex justify-between text-sm border-t border-dark-border pt-2 mt-2">
              <span className="text-gray-400">Potential Win</span>
              <span className="text-brand font-bold">{formatMWK(lastTicket.potential_win * 0.8)}</span>
            </div>
          </div>

          <button onClick={() => setLastTicket(null)} className="btn-primary w-full text-sm">
            Place Another Bet
          </button>
          <button
            onClick={() => router.push('/tickets')}
            className="text-gray-400 text-sm mt-3 hover:text-white w-full text-center"
          >
            View My Tickets →
          </button>
        </div>
      </div>
    );
  }

  // ── Empty State ───────────────────────────────────────────────────────────
  if (selections.length === 0) {
    return (
      <div className="card p-6 text-center sticky top-4">
        <div className="text-4xl mb-3">🎯</div>
        <h3 className="text-white font-semibold mb-2">Your Bet Slip is Empty</h3>
        <p className="text-gray-500 text-sm">Select odds from events to build your bet slip.</p>
      </div>
    );
  }

  // ── Active Bet Slip ───────────────────────────────────────────────────────
  return (
    <div className="card sticky top-4 animate-slide-up">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-dark-border">
        <div className="flex items-center gap-2">
          <span className="text-white font-bold">Bet Slip</span>
          <span className="bg-brand text-black text-xs font-bold px-2 py-0.5 rounded-full">
            {selections.length}
          </span>
        </div>
        <button onClick={clearSlip} className="text-gray-400 hover:text-red-400 text-xs transition-colors">
          Clear all
        </button>
      </div>

      {/* Selections */}
      <div className="p-3 space-y-2 max-h-64 overflow-y-auto">
        {selections.map((sel, i) => (
          <div key={`${sel.market_id}-${sel.selection}`} className="bet-slip-item">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium truncate">
                  {sel.label || sel.selection}
                </p>
                <p className="text-gray-500 text-xs truncate">
                  {sel.home_team} vs {sel.away_team}
                </p>
              </div>
              <div className="flex items-center gap-2 ml-2">
                <span className="text-brand font-bold text-sm">{formatOdds(sel.odds)}</span>
                <button
                  onClick={() => removeSelection(sel.market_id, sel.selection)}
                  className="text-gray-500 hover:text-red-400 text-lg leading-none transition-colors"
                >
                  ×
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bet Type Badge */}
      <div className="px-4 pb-2">
        <span className="text-xs text-gray-400 bg-dark-surface px-2 py-1 rounded">
          {betType}
        </span>
        {selections.length > 1 && (
          <span className="text-xs text-brand ml-2 font-bold">
            × {formatOdds(totalOdds)} odds
          </span>
        )}
      </div>

      {/* Stake Input */}
      <div className="px-4 pb-3 border-t border-dark-border pt-3">
        <label className="text-xs text-gray-400 mb-2 block">Stake (MWK)</label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">MWK</span>
          <input
            type="number"
            value={stake}
            onChange={e => setStake(e.target.value)}
            placeholder="0.00"
            min="50"
            className="input pl-14 text-right text-white font-bold"
          />
        </div>

        {/* Quick stake buttons */}
        <div className="flex gap-1.5 mt-2 flex-wrap">
          {QUICK_STAKES.map(amt => (
            <button
              key={amt}
              onClick={() => setStake(amt.toString())}
              className="text-xs px-2 py-1 bg-dark-surface border border-dark-border rounded hover:border-brand hover:text-brand transition-colors text-gray-400"
            >
              {amt >= 1000 ? `${amt/1000}K` : amt}
            </button>
          ))}
        </div>

        {/* Balance indicator */}
        {isAuthenticated && (
          <p className="text-xs text-gray-500 mt-2">
            Available: <span className="text-white">{formatMWK(available)}</span>
            {bonusBalance > 0 && (
              <span className="text-brand ml-2">+{formatMWK(bonusBalance)} bonus</span>
            )}
          </p>
        )}
      </div>

      {/* Bonus toggle */}
      {isAuthenticated && bonusBalance > 0 && (
        <div className="px-4 pb-3 flex items-center gap-2">
          <input
            type="checkbox"
            id="use-bonus"
            checked={useBonus}
            onChange={e => setUseBonus(e.target.checked)}
            className="accent-brand"
          />
          <label htmlFor="use-bonus" className="text-xs text-gray-400 cursor-pointer">
            Use bonus balance ({formatMWK(bonusBalance)})
          </label>
        </div>
      )}

      {/* Summary */}
      {stake && parseFloat(stake) >= 50 && (
        <div className="px-4 pb-3 bg-dark-surface mx-3 rounded-lg">
          <div className="flex justify-between text-sm py-1">
            <span className="text-gray-400">Total odds</span>
            <span className="text-white font-bold">{formatOdds(totalOdds)}</span>
          </div>
          <div className="flex justify-between text-sm py-1">
            <span className="text-gray-400">Potential win</span>
            <span className="text-brand font-bold">{formatMWK(potentialWin)}</span>
          </div>
          <p className="text-xs text-gray-600 mt-1">After 20% withholding tax</p>
        </div>
      )}

      {/* Place Bet Button */}
      <div className="p-4">
        <button
          onClick={placeBet}
          disabled={loading || !stake || parseFloat(stake) < 50}
          className="btn-primary w-full text-base"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
              Placing Bet...
            </span>
          ) : isAuthenticated ? (
            `Place Bet — ${formatMWK(stake || 0)}`
          ) : (
            'Login to Place Bet'
          )}
        </button>
        <p className="text-center text-xs text-gray-600 mt-2">
          18+ | Bet Responsibly | kwachabet.mw
        </p>
      </div>
    </div>
  );
}
