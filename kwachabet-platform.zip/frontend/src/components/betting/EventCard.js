/**
 * EventCard - Displays a single event with odds buttons
 * Supports h2h (Home/Draw/Away) and live events
 */

import { useState, useEffect, useRef } from 'react';
import { format } from 'date-fns';
import { useBetSlipStore } from '../../store';

function OddsButton({ market, event, selection }) {
  const { addSelection, selections } = useBetSlipStore();
  const [flash, setFlash] = useState(false);
  const prevOdds = useRef(parseFloat(market.odds));

  const isSelected = selections.some(
    s => s.market_id === market.id && s.selection === selection
  );

  // Flash on odds change
  useEffect(() => {
    const newOdds = parseFloat(market.odds);
    if (newOdds !== prevOdds.current) {
      setFlash(true);
      setTimeout(() => setFlash(false), 600);
      prevOdds.current = newOdds;
    }
  }, [market.odds]);

  const handleClick = () => {
    addSelection({
      market_id: market.id,
      event_id: event.id,
      selection,
      odds: parseFloat(market.odds),
      home_team: event.home_team,
      away_team: event.away_team,
      market_type: market.market_type,
      label: getSelectionLabel(selection, event),
    });
  };

  return (
    <button
      onClick={handleClick}
      className={`odds-btn flex-1 text-center ${isSelected ? 'selected' : ''} ${flash ? 'flashing' : ''}`}
    >
      <div className="text-xs text-gray-400 mb-0.5">{getSelectionLabel(selection, event)}</div>
      <div className={`text-sm font-bold ${isSelected ? 'text-brand' : 'text-white'}`}>
        {parseFloat(market.odds).toFixed(2)}
      </div>
    </button>
  );
}

function getSelectionLabel(selection, event) {
  if (selection === '1' || selection === event.home_team) return '1';
  if (selection === 'Draw' || selection === 'X') return 'X';
  if (selection === '2' || selection === event.away_team) return '2';
  return selection;
}

export default function EventCard({ event }) {
  const h2hMarkets = (event.markets || []).filter(m => m.market_type === 'h2h');
  const homeMarket = h2hMarkets.find(m => m.outcome === event.home_team || m.outcome === '1');
  const drawMarket = h2hMarkets.find(m => m.outcome === 'Draw' || m.outcome === 'X');
  const awayMarket = h2hMarkets.find(m => m.outcome === event.away_team || m.outcome === '2');

  const isLive = event.status === 'live';
  const commenceTime = new Date(event.commence_time);

  return (
    <div className={`card p-4 hover:border-dark-border/80 transition-all ${isLive ? 'border-red-800/50' : ''}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {isLive ? (
            <span className="live-badge">LIVE</span>
          ) : (
            <span className="text-xs text-gray-500">
              {format(commenceTime, 'dd MMM HH:mm')}
            </span>
          )}
          {event.league && (
            <span className="text-xs text-gray-500 truncate max-w-32">{event.league}</span>
          )}
        </div>
        {isLive && event.home_score !== null && (
          <div className="flex items-center gap-1 text-sm font-bold text-white">
            <span>{event.home_score}</span>
            <span className="text-gray-500">-</span>
            <span>{event.away_score}</span>
          </div>
        )}
      </div>

      {/* Teams */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex-1">
          <p className="font-semibold text-white text-sm truncate">{event.home_team}</p>
          <p className="font-semibold text-white text-sm truncate">{event.away_team}</p>
        </div>
      </div>

      {/* Odds */}
      <div className="flex gap-2">
        {homeMarket && <OddsButton market={homeMarket} event={event} selection={event.home_team} />}
        {drawMarket && <OddsButton market={drawMarket} event={event} selection="Draw" />}
        {awayMarket && <OddsButton market={awayMarket} event={event} selection={event.away_team} />}
        {!homeMarket && !drawMarket && !awayMarket && (
          <p className="text-xs text-gray-500 text-center w-full py-2">Odds not available</p>
        )}
      </div>

      {/* More markets link */}
      <div className="mt-2 text-right">
        <span className="text-xs text-gray-500 hover:text-brand cursor-pointer transition-colors">
          +{Math.max(0, (event.markets || []).length - 3)} more markets →
        </span>
      </div>
    </div>
  );
}
