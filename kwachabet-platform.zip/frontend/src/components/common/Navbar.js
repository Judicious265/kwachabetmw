/**
 * Navbar - Top navigation with wallet balance and user menu
 */

import Link from 'next/link';
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import { useAuthStore, useWalletStore } from '../../store';
import { walletAPI } from '../../utils/api';

function formatMWK(n) {
  return `MWK ${parseFloat(n || 0).toLocaleString('en-MW', { minimumFractionDigits: 2 })}`;
}

export default function Navbar() {
  const router = useRouter();
  const { isAuthenticated, user, logout } = useAuthStore();
  const { balance, setWallet } = useWalletStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      walletAPI.getBalance()
        .then(res => setWallet(res.data))
        .catch(() => {});
    }
  }, [isAuthenticated]);

  return (
    <nav className="bg-dark-surface border-b border-dark-border sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-14">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center">
              <span className="text-black font-black text-sm">K</span>
            </div>
            <span className="text-white font-black text-lg">
              Kwacha<span className="text-brand">Bet</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6 text-sm text-gray-400">
            <Link href="/" className="hover:text-white transition-colors">Sports</Link>
            <Link href="/live" className="hover:text-white transition-colors flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
              Live
            </Link>
            <Link href="/results" className="hover:text-white transition-colors">Results</Link>
            <Link href="/tickets" className="hover:text-white transition-colors">My Tickets</Link>
          </div>

          {/* Auth section */}
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                {/* Balance */}
                <Link href="/wallet" className="hidden md:flex items-center gap-2 bg-dark-card border border-dark-border rounded-lg px-3 py-1.5 hover:border-brand transition-colors">
                  <span className="text-brand text-xs font-bold">MWK</span>
                  <span className="text-white font-bold text-sm">{parseFloat(balance).toLocaleString('en-MW', { minimumFractionDigits: 2 })}</span>
                </Link>

                {/* Deposit */}
                <Link href="/deposit" className="btn-primary text-sm py-2 px-4 hidden md:block">
                  + Deposit
                </Link>

                {/* User menu */}
                <div className="relative">
                  <button
                    onClick={() => setMenuOpen(!menuOpen)}
                    className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors"
                  >
                    <div className="w-8 h-8 bg-brand/20 border border-brand/30 rounded-full flex items-center justify-center">
                      <span className="text-brand text-xs font-bold">
                        {user?.full_name?.charAt(0)?.toUpperCase() || 'U'}
                      </span>
                    </div>
                  </button>

                  {menuOpen && (
                    <div className="absolute right-0 top-full mt-2 w-52 bg-dark-card border border-dark-border rounded-xl shadow-xl z-50">
                      <div className="px-4 py-3 border-b border-dark-border">
                        <p className="text-white font-semibold text-sm truncate">{user?.full_name}</p>
                        <p className="text-gray-500 text-xs">{user?.phone}</p>
                      </div>
                      <div className="py-2">
                        {[
                          { href: '/wallet',  label: 'Wallet' },
                          { href: '/tickets', label: 'My Tickets' },
                          { href: '/profile', label: 'Profile' },
                          { href: '/referral',label: 'Refer & Earn' },
                        ].map(item => (
                          <Link key={item.href} href={item.href}
                            className="block px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-dark-hover transition-colors"
                            onClick={() => setMenuOpen(false)}>
                            {item.label}
                          </Link>
                        ))}
                        {user?.is_admin && (
                          <Link href="/admin" className="block px-4 py-2 text-sm text-brand hover:bg-dark-hover" onClick={() => setMenuOpen(false)}>
                            Admin Panel
                          </Link>
                        )}
                        <button
                          onClick={() => { setMenuOpen(false); logout(); }}
                          className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-dark-hover transition-colors"
                        >
                          Logout
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <Link href="/login" className="text-sm text-gray-300 hover:text-white transition-colors hidden md:block">
                  Login
                </Link>
                <Link href="/register" className="btn-primary text-sm py-2 px-4">
                  Join Now
                </Link>
              </>
            )}

            {/* Mobile menu toggle */}
            <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden text-gray-400 hover:text-white">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden border-t border-dark-border py-3 space-y-2">
            {['/', '/live', '/tickets', '/wallet', '/deposit'].map(href => (
              <Link key={href} href={href}
                className="block px-2 py-2 text-sm text-gray-300 hover:text-white"
                onClick={() => setMobileOpen(false)}>
                {href === '/' ? 'Sports' : href.slice(1).charAt(0).toUpperCase() + href.slice(2)}
              </Link>
            ))}
            {!isAuthenticated && (
              <Link href="/login" className="block px-2 py-2 text-sm text-brand" onClick={() => setMobileOpen(false)}>
                Login / Register
              </Link>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}

/* ─────────────────────────────────────────────────────────────────────────── */

/**
 * LiveTicker - Scrolling ticker of live events
 */
export function LiveTicker({ events = [] }) {
  const liveEvents = events.filter(e => e.status === 'live').slice(0, 10);
  if (liveEvents.length === 0) return null;

  return (
    <div className="bg-dark-card border-b border-dark-border overflow-hidden">
      <div className="flex items-center">
        <div className="flex-shrink-0 bg-red-600 text-white text-xs font-bold px-3 py-1.5 mr-3">
          LIVE
        </div>
        <div className="overflow-hidden flex-1 py-1.5">
          <div className="flex animate-ticker whitespace-nowrap gap-8">
            {[...liveEvents, ...liveEvents].map((event, i) => (
              <span key={`${event.id}-${i}`} className="text-xs text-gray-300 inline-flex items-center gap-2">
                <span className="text-white font-medium">{event.home_team}</span>
                <span className="text-brand font-bold">
                  {event.home_score} - {event.away_score}
                </span>
                <span className="text-white font-medium">{event.away_team}</span>
                <span className="text-dark-border">|</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
