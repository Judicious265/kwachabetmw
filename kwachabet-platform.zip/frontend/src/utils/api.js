/**
 * API Client - Axios with auth interceptors
 */

import axios from 'axios';
import Cookies from 'js-cookie';
import toast from 'react-hot-toast';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'https://api.kwachabet.mw/api/v1';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT token
api.interceptors.request.use((config) => {
  const token = Cookies.get('kb_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  const deviceFp = localStorage.getItem('kb_device_fp');
  if (deviceFp) config.headers['X-Device-Fingerprint'] = deviceFp;
  return config;
});

// Handle errors globally
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const msg = err.response?.data?.error || 'Something went wrong.';
    if (err.response?.status === 401) {
      Cookies.remove('kb_token');
      if (typeof window !== 'undefined' && !window.location.pathname.includes('/login')) {
        window.location.href = '/login';
      }
    } else if (err.response?.status === 429) {
      toast.error('Too many requests. Please wait and try again.');
    } else if (err.response?.status >= 500) {
      toast.error('Server error. Please try again later.');
    }
    return Promise.reject({ message: msg, status: err.response?.status });
  }
);

// ─── Auth ─────────────────────────────────────────────────────────────────────
export const authAPI = {
  initiateRegister: (data) => api.post('/auth/register/initiate', data),
  verifyRegister:   (data) => api.post('/auth/register/verify', data),
  login:            (data) => api.post('/auth/login', data),
  setPin:           (data) => api.post('/auth/pin/set', data),
  verifyPin:        (data) => api.post('/auth/pin/verify', data),
  requestOTP:       ()     => api.post('/auth/otp/withdrawal'),
};

// ─── Wallet ───────────────────────────────────────────────────────────────────
export const walletAPI = {
  getBalance:      ()     => api.get('/wallet/balance'),
  getTransactions: (p)    => api.get('/wallet/transactions', { params: p }),
  deposit:         (data) => api.post('/wallet/deposit', data),
  withdraw:        (data) => api.post('/wallet/withdraw', data),
};

// ─── Betting ──────────────────────────────────────────────────────────────────
export const bettingAPI = {
  placeBet:   (data)   => api.post('/betting/place', data),
  getTickets: (params) => api.get('/betting/tickets', { params }),
  getTicket:  (code)   => api.get(`/betting/tickets/${code}`),
  checkTicket:(code)   => api.get(`/betting/check/${code}`),
};

// ─── Odds / Sports ────────────────────────────────────────────────────────────
export const oddsAPI = {
  getEvents:   (params) => api.get('/odds/events', { params }),
  getFeatured: ()       => api.get('/odds/featured'),
  getSports:   ()       => api.get('/odds/sports'),
};

// ─── Admin ────────────────────────────────────────────────────────────────────
export const adminAPI = {
  getDashboard:         () => api.get('/admin/dashboard/stats'),
  getUsers:             (p) => api.get('/admin/users', { params: p }),
  getUserDetail:        (id) => api.get(`/admin/users/${id}`),
  suspendUser:          (id, reason) => api.patch(`/admin/users/${id}/suspend`, { reason }),
  unsuspendUser:        (id) => api.patch(`/admin/users/${id}/unsuspend`),
  getTickets:           (p) => api.get('/admin/tickets', { params: p }),
  getPendingWithdrawals: () => api.get('/admin/withdrawals/pending'),
  approveWithdrawal:    (id) => api.patch(`/admin/withdrawals/${id}/approve`),
  rejectWithdrawal:     (id, reason) => api.patch(`/admin/withdrawals/${id}/reject`, { reason }),
  getFraudDashboard:    (p) => api.get('/admin/fraud/dashboard', { params: p }),
  resolveFraudFlag:     (id, notes) => api.patch(`/admin/fraud/flags/${id}/resolve`, { notes }),
  blacklistDevice:      (data) => api.post('/admin/fraud/blacklist/device', data),
  assignFreeBet:        (data) => api.post('/admin/bonus/free-bet', data),
  getCampaigns:         () => api.get('/admin/bonus/campaigns'),
  createCampaign:       (data) => api.post('/admin/bonus/campaigns', data),
};

export default api;
