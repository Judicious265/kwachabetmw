const { createClient } = require('redis');
const logger = require('../utils/logger');

const redisClient = createClient({
  url: process.env.REDIS_URL,
  password: process.env.REDIS_PASSWORD || undefined,
  socket: { reconnectStrategy: retries => Math.min(retries * 100, 5000) },
});

redisClient.on('error', err => logger.error('Redis error:', err));
redisClient.on('reconnecting', () => logger.warn('Redis reconnecting...'));
redisClient.on('ready', () => logger.info('Redis ready'));

// Cache helpers
const cache = {
  async get(key) {
    const val = await redisClient.get(key);
    return val ? JSON.parse(val) : null;
  },
  async set(key, value, ttlSeconds = 300) {
    await redisClient.setEx(key, ttlSeconds, JSON.stringify(value));
  },
  async del(key) {
    await redisClient.del(key);
  },
  async incr(key) {
    return redisClient.incr(key);
  },
  async expire(key, ttl) {
    return redisClient.expire(key, ttl);
  },
};

module.exports = { redisClient, cache };
