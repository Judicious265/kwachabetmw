/**
 * Database Configuration - PostgreSQL via Sequelize
 * Supports SSL in production, connection pooling
 */

const { Sequelize } = require('sequelize');
const logger = require('../utils/logger');

const isProd = process.env.NODE_ENV === 'production';

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT) || 5432,
    dialect: 'postgres',
    logging: isProd ? false : (sql) => logger.debug(sql),
    pool: {
      max: 20,
      min: 2,
      acquire: 30000,
      idle: 10000,
    },
    dialectOptions: isProd ? {
      ssl: {
        require: true,
        rejectUnauthorized: true,
      },
    } : {},
    define: {
      underscored: true,
      timestamps: true,
    },
  }
);

module.exports = { sequelize };
