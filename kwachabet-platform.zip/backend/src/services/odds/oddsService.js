/**
 * Odds Service
 * Fetches live/upcoming odds from the-odds-api.com
 * Broadcasts updates via WebSocket to connected clients
 */

const axios = require('axios');
const { Market, Event } = require('../../models');
const { cache } = require('../../config/redis');
const logger = require('../../utils/logger');

const BASE_URL = process.env.ODDS_API_BASE_URL || 'https://api.the-odds-api.com/v4';
const API_KEY = process.env.ODDS_API_KEY;

// Sports mapping: our IDs → Odds API keys
const SPORT_MAP = {
  football:     'soccer_epl',
  basketball:   'basketball_nba',
  tennis:       'tennis_atp_french_open',
  ice_hockey:   'icehockey_nhl',
  baseball:     'baseball_mlb',
  rugby_league: 'rugbyleague_nrl',
};

const ALL_SPORTS = Object.values(SPORT_MAP);

const client = axios.create({
  baseURL: BASE_URL,
  params: { apiKey: API_KEY, regions: 'uk', markets: 'h2h', oddsFormat: 'decimal' },
  timeout: 20000,
});

// ─── Fetch odds for all active sports ────────────────────────────────────────

exports.fetchAllOdds = async () => {
  const results = [];

  for (const [sportKey, apiSport] of Object.entries(SPORT_MAP)) {
    try {
      const odds = await exports.fetchSportOdds(sportKey, apiSport);
      results.push(...odds);
    } catch (err) {
      logger.error(`Failed to fetch odds for ${sportKey}:`, err.message);
    }
  }

  return results;
};

exports.fetchSportOdds = async (sportKey, apiSport) => {
  const cacheKey = `odds:${sportKey}`;
  const cached = await cache.get(cacheKey);
  if (cached) return cached;

  const res = await client.get(`/sports/${apiSport}/odds`, {
    params: { markets: 'h2h,spreads' },
  });

  const games = res.data;

  // Upsert events and markets
  const processed = [];
  for (const game of games) {
    const eventData = {
      external_id: game.id,
      sport_id: sportKey,
      home_team: game.home_team,
      away_team: game.away_team,
      league: apiSport,
      commence_time: new Date(game.commence_time),
      status: new Date(game.commence_time) < new Date() ? 'live' : 'upcoming',
    };

    const [event] = await Event.upsert(eventData, { returning: true });

    // Parse odds from best bookmaker
    if (game.bookmakers && game.bookmakers.length > 0) {
      const bookmaker = game.bookmakers[0];
      const h2hMarket = bookmaker.markets.find(m => m.key === 'h2h');

      if (h2hMarket) {
        for (const outcome of h2hMarket.outcomes) {
          await Market.upsert({
            event_id: event.id,
            market_type: 'h2h',
            outcome: outcome.name,
            odds: parseFloat(outcome.price),
            bookmaker: bookmaker.key,
            is_active: true,
            updated_at: new Date(),
          });
        }
      }
    }

    processed.push({
      event_id: event.id,
      external_id: game.id,
      home_team: game.home_team,
      away_team: game.away_team,
      sport: sportKey,
      commence_time: game.commence_time,
    });
  }

  await cache.set(cacheKey, processed, 120); // 2 min cache
  return processed;
};

// ─── Get featured events for homepage ────────────────────────────────────────

exports.getFeaturedEvents = async () => {
  const cacheKey = 'events:featured';
  const cached = await cache.get(cacheKey);
  if (cached) return cached;

  const events = await Event.findAll({
    where: { status: ['upcoming', 'live'] },
    include: [{ model: Market, as: 'markets', where: { market_type: 'h2h', is_active: true } }],
    order: [['commence_time', 'ASC']],
    limit: 20,
  });

  await cache.set(cacheKey, events, 60);
  return events;
};

// ─── WebSocket server for live odds broadcasting ──────────────────────────────

exports.setupWebSocket = (wss) => {
  const clients = new Set();

  wss.on('connection', (ws, req) => {
    logger.info(`WS client connected: ${req.socket.remoteAddress}`);
    clients.add(ws);

    // Send current odds immediately on connect
    exports.getFeaturedEvents()
      .then(events => ws.send(JSON.stringify({ type: 'odds_update', events })))
      .catch(err => logger.error('WS initial send error:', err));

    ws.on('message', async (data) => {
      try {
        const { type, sport } = JSON.parse(data);
        if (type === 'subscribe_sport' && sport) {
          ws.subscribedSport = sport;
        }
      } catch {}
    });

    ws.on('close', () => {
      clients.delete(ws);
      logger.info('WS client disconnected');
    });

    ws.on('error', () => clients.delete(ws));
  });

  // Broadcast odds update to all connected clients
  exports.broadcastOddsUpdate = (events) => {
    const payload = JSON.stringify({ type: 'odds_update', timestamp: Date.now(), events });
    for (const ws of clients) {
      if (ws.readyState === 1) { // OPEN
        try { ws.send(payload); } catch {}
      }
    }
    logger.debug(`Odds broadcast to ${clients.size} WS clients`);
  };

  return { clients, broadcast: exports.broadcastOddsUpdate };
};
