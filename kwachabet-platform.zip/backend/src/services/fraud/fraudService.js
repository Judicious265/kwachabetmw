/**
 * Fraud Detection Service
 * Dynamic risk scoring, rules engine, device tracking, withdrawal protection
 * All rules are configurable and audit-logged
 */

const { User, FraudFlag, UserSession, BlacklistedDevice, Withdrawal, Ticket, Transaction } = require('../../models');
const { sequelize } = require('../../config/database');
const { cache } = require('../../config/redis');
const logger = require('../../utils/logger');

// ─── Fraud Rules Configuration ────────────────────────────────────────────────
// These rules are checked in order; higher severity = more urgent

const FRAUD_RULES = [
  {
    code: 'RAPID_WITHDRAWAL',
    description: 'Multiple withdrawals within short timeframe',
    severity: 'high',
    check: async (userId) => {
      const count = await Withdrawal.count({
        where: {
          user_id: userId,
          created_at: { [Op.gte]: new Date(Date.now() - 24 * 60 * 60 * 1000) },
          status: { [Op.not]: 'failed' },
        },
      });
      return count >= parseInt(process.env.FRAUD_MAX_DAILY_WITHDRAWALS) || 5;
    },
    scoreImpact: 40,
  },
  {
    code: 'NEW_ACCOUNT_HIGH_WITHDRAWAL',
    description: 'High withdrawal amount from recently created account',
    severity: 'high',
    check: async (userId, context) => {
      const user = await User.findByPk(userId);
      const agedays = (Date.now() - user.created_at.getTime()) / (1000 * 60 * 60 * 24);
      return agedays < parseInt(process.env.FRAUD_NEW_ACCOUNT_DAYS || 30)
        && context.amount > 100000;
    },
    scoreImpact: 35,
  },
  {
    code: 'UNUSUAL_WIN_PATTERN',
    description: 'Repeated high-odds wins in short period',
    severity: 'medium',
    check: async (userId) => {
      const wins = await Ticket.findAll({
        where: {
          user_id: userId,
          status: 'won',
          settled_at: { [Op.gte]: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
        },
      });
      const highOddsWins = wins.filter(t => parseFloat(t.total_odds) > 50);
      return highOddsWins.length >= 3;
    },
    scoreImpact: 30,
  },
  {
    code: 'DEVICE_MULTI_ACCOUNT',
    description: 'Multiple accounts from same device fingerprint',
    severity: 'critical',
    check: async (userId, context) => {
      if (!context.fingerprint) return false;
      const sessions = await UserSession.findAll({
        where: { device_fingerprint: context.fingerprint },
        attributes: ['user_id'],
        group: ['user_id'],
      });
      return sessions.length > 1 && !sessions.every(s => s.user_id === userId);
    },
    scoreImpact: 50,
  },
  {
    code: 'IP_MULTI_ACCOUNT',
    description: 'Multiple accounts from same IP address',
    severity: 'high',
    check: async (userId, context) => {
      if (!context.ip) return false;
      const { Op } = require('sequelize');
      const sessions = await UserSession.findAll({
        where: {
          ip_address: context.ip,
          user_id: { [Op.ne]: userId },
        },
        attributes: ['user_id'],
        group: ['user_id'],
      });
      return sessions.length >= 2;
    },
    scoreImpact: 25,
  },
  {
    code: 'NON_MALAWI_LOGIN',
    description: 'Login attempt from outside Malawi',
    severity: 'medium',
    check: async (userId, context) => {
      return context.country && context.country !== 'MW';
    },
    scoreImpact: 20,
  },
  {
    code: 'RAPID_DEPOSIT_WITHDRAWAL',
    description: 'Deposit followed immediately by large withdrawal',
    severity: 'high',
    check: async (userId, context) => {
      const { Op } = require('sequelize');
      const recentDeposit = await Transaction.findOne({
        where: {
          user_id: userId,
          type: 'deposit',
          created_at: { [Op.gte]: new Date(Date.now() - 60 * 60 * 1000) },
        },
        order: [['created_at', 'DESC']],
      });
      return !!recentDeposit && context.amount > parseFloat(recentDeposit.amount) * 0.9;
    },
    scoreImpact: 45,
  },
];

// ─── Score a withdrawal request ────────────────────────────────────────────────

exports.scoreWithdrawal = async (userId, amount, user) => {
  const { Op } = require('sequelize');
  let score = 0;
  const triggeredRules = [];

  const context = { amount, ip: user.last_login_ip };

  for (const rule of FRAUD_RULES) {
    try {
      const triggered = await rule.check(userId, context);
      if (triggered) {
        score += rule.scoreImpact;
        triggeredRules.push({ code: rule.code, severity: rule.severity });
        logger.warn(`Fraud rule triggered: ${rule.code} for user ${userId}`);
      }
    } catch (err) {
      logger.error(`Fraud rule check failed: ${rule.code}`, err);
    }
  }

  score = Math.min(100, score);

  // Update user risk score (weighted moving average)
  const currentScore = user.risk_score || 0;
  const newScore = Math.round((currentScore * 0.7) + (score * 0.3));
  await User.update({ risk_score: newScore }, { where: { id: userId } });

  return { score, triggeredRules, blocked: score >= 90 };
};

// ─── Check login event for suspicious activity ────────────────────────────────

exports.checkLoginEvent = async (user, ip, fingerprint) => {
  // Check blacklisted device
  if (fingerprint) {
    const blacklisted = await BlacklistedDevice.findOne({ where: { fingerprint } });
    if (blacklisted) {
      throw new Error('Device is blocked. Contact support.');
    }
  }

  // Check for suspicious country
  // (In production: use MaxMind GeoIP or ip-api.com)
  const context = { ip, fingerprint };

  const rule = FRAUD_RULES.find(r => r.code === 'DEVICE_MULTI_ACCOUNT');
  if (rule) {
    const triggered = await rule.check(user.id, context).catch(() => false);
    if (triggered) {
      await exports.createFlag(user.id, 'DEVICE_MULTI_ACCOUNT', context, 'critical');
    }
  }
};

// ─── Check betting pattern ─────────────────────────────────────────────────────

exports.checkBettingPattern = async (userId, selections, stake) => {
  const { Op } = require('sequelize');
  const cacheKey = `bet:count:${userId}:${Math.floor(Date.now() / 60000)}`;

  const betCount = await cache.incr(cacheKey);
  if (betCount === 1) await cache.expire(cacheKey, 60);

  // Block if > 30 bets per minute (bot behavior)
  if (betCount > 30) {
    await exports.createFlag(userId, 'BET_RATE_LIMIT', { bets_per_min: betCount }, 'high');
    return { blocked: true };
  }

  return { blocked: false };
};

// ─── Create fraud flag ────────────────────────────────────────────────────────

exports.createFlag = async (userId, ruleCode, metadata = {}, severity = 'medium') => {
  const rule = FRAUD_RULES.find(r => r.code === ruleCode);
  const description = rule?.description || ruleCode;

  await FraudFlag.create({
    user_id: userId,
    rule_code: ruleCode,
    severity,
    description,
    metadata,
  });

  logger.warn(`Fraud flag created: user=${userId} rule=${ruleCode} severity=${severity}`);
};

// ─── Flag withdrawal for manual review ───────────────────────────────────────

exports.flagWithdrawal = async (userId, withdrawalId, fraudResult) => {
  await exports.createFlag(userId, 'WITHDRAWAL_FLAGGED', {
    withdrawal_id: withdrawalId,
    score: fraudResult.score,
    rules: fraudResult.triggeredRules,
  }, fraudResult.score >= 80 ? 'critical' : 'high');
};

// ─── Admin: Get fraud dashboard data ──────────────────────────────────────────

exports.getFraudDashboard = async ({ page = 1, limit = 20 } = {}) => {
  const { Op } = require('sequelize');
  const offset = (page - 1) * limit;

  const [flags, suspiciousUsers, pendingWithdrawals] = await Promise.all([
    FraudFlag.findAndCountAll({
      where: { resolved: false },
      order: [['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
      include: [{ model: User, as: 'user', attributes: ['id','phone','full_name','risk_score'] }],
    }),
    User.findAll({
      where: { risk_score: { [Op.gte]: 60 } },
      order: [['risk_score', 'DESC']],
      limit: 20,
      attributes: ['id','phone','full_name','risk_score','created_at'],
    }),
    Withdrawal.count({ where: { status: 'flagged' } }),
  ]);

  return { flags, suspiciousUsers, pendingWithdrawals };
};
