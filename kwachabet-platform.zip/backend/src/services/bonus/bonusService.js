/**
 * Bonus Service
 * Welcome bonus, free bets, referral rewards, wagering requirements
 */

const { UserBonus, BonusCampaign, Wallet, Referral, User, Transaction } = require('../../models');
const smsService = require('../sms/smsService');
const { sequelize } = require('../../config/database');
const logger = require('../../utils/logger');

const WELCOME_BONUS_PERCENT = parseFloat(process.env.WELCOME_BONUS_PERCENT) || 100;
const WELCOME_BONUS_MAX = parseFloat(process.env.WELCOME_BONUS_MAX_MWK) || 50000;
const WAGERING_REQ = parseFloat(process.env.WELCOME_BONUS_WAGERING) || 5;
const REFERRAL_BONUS = parseFloat(process.env.REFERRAL_BONUS_MWK) || 2000;

// ─── Apply Welcome Bonus on First Deposit ────────────────────────────────────

exports.applyWelcomeBonus = async (userId, depositAmount, transaction) => {
  try {
    // Check if already claimed welcome bonus
    const existing = await UserBonus.findOne({
      where: { user_id: userId, type: 'welcome' },
      transaction,
    });
    if (existing) return null;

    const campaign = await BonusCampaign.findOne({
      where: { type: 'welcome', is_active: true },
      transaction,
    });
    if (!campaign) return null;

    const minDeposit = parseFloat(campaign.min_deposit) || 500;
    if (parseFloat(depositAmount) < minDeposit) return null;

    const bonusAmount = Math.min(
      parseFloat(depositAmount) * (WELCOME_BONUS_PERCENT / 100),
      WELCOME_BONUS_MAX
    );

    const requiredWager = bonusAmount * WAGERING_REQ;
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    const userBonus = await UserBonus.create({
      user_id: userId,
      campaign_id: campaign.id,
      type: 'welcome',
      bonus_amount: bonusAmount,
      required_wager: requiredWager,
      wagered_amount: 0,
      status: 'active',
      expires_at: expiresAt,
    }, { transaction });

    // Credit bonus wallet
    await Wallet.update(
      { bonus_balance: sequelize.literal(`bonus_balance + ${bonusAmount}`) },
      { where: { user_id: userId }, transaction }
    );

    // Notify user
    const user = await User.findByPk(userId, { transaction });
    setImmediate(() => smsService.sendBonusNotification(user.phone, bonusAmount, '100% Welcome', userId));

    logger.info(`Welcome bonus applied: user=${userId} amount=${bonusAmount} MWK`);
    return userBonus;
  } catch (err) {
    logger.error('applyWelcomeBonus error:', err);
    return null;
  }
};

// ─── Get usable bonus for a bet ───────────────────────────────────────────────

exports.getUsableBonusForBet = async (userId, odds, transaction) => {
  const bonus = await UserBonus.findOne({
    where: { user_id: userId, status: 'active' },
    include: [{ model: BonusCampaign, as: 'campaign' }],
    transaction,
  });

  if (!bonus) return 0;

  const minOdds = parseFloat(bonus.campaign?.min_odds) || 1.5;
  if (odds < minOdds) return 0;

  if (new Date() > bonus.expires_at) {
    await bonus.update({ status: 'expired' }, { transaction });
    return 0;
  }

  const wallet = await Wallet.findOne({ where: { user_id: userId }, transaction });
  return parseFloat(wallet.bonus_balance);
};

// ─── Record wager progress ────────────────────────────────────────────────────

exports.recordWager = async (userId, stakeAmount, transaction) => {
  const bonus = await UserBonus.findOne({
    where: { user_id: userId, status: 'active' },
    transaction,
    lock: true,
  });

  if (!bonus) return;

  const newWagered = parseFloat(bonus.wagered_amount) + parseFloat(stakeAmount);
  const required = parseFloat(bonus.required_wager);

  if (newWagered >= required) {
    // Bonus fully wagered - convert to real cash
    const wallet = await Wallet.findOne({ where: { user_id: userId }, transaction });
    const bonusBalance = parseFloat(wallet.bonus_balance);

    if (bonusBalance > 0) {
      await wallet.update({
        balance: sequelize.literal(`balance + ${bonusBalance}`),
        bonus_balance: 0,
      }, { transaction });

      await Transaction.create({
        user_id: userId,
        wallet_id: wallet.id,
        type: 'bonus_credit',
        amount: bonusBalance,
        balance_before: parseFloat(wallet.balance),
        balance_after: parseFloat(wallet.balance) + bonusBalance,
        status: 'completed',
        metadata: { reason: 'wagering_complete', bonus_id: bonus.id },
      }, { transaction });
    }

    await bonus.update({ status: 'completed', wagered_amount: newWagered }, { transaction });
    logger.info(`Bonus wagering complete: user=${userId} bonus=${bonus.id}`);
  } else {
    await bonus.update({ wagered_amount: newWagered }, { transaction });
  }
};

// ─── Process referral reward ──────────────────────────────────────────────────

exports.processReferralReward = async (referredUserId) => {
  return sequelize.transaction(async (t) => {
    const referral = await Referral.findOne({
      where: { referred_id: referredUserId, status: 'pending' },
      transaction: t,
    });

    if (!referral) return;

    // Only reward after first deposit (already deposited by this point)
    const referrer = await User.findByPk(referral.referrer_id, { transaction: t });
    const referrerWallet = await Wallet.findOne({
      where: { user_id: referral.referrer_id }, transaction: t, lock: true,
    });

    const balanceBefore = parseFloat(referrerWallet.balance);
    await referrerWallet.update({ balance: balanceBefore + REFERRAL_BONUS }, { transaction: t });

    await Transaction.create({
      user_id: referral.referrer_id,
      wallet_id: referrerWallet.id,
      type: 'referral_bonus',
      amount: REFERRAL_BONUS,
      balance_before: balanceBefore,
      balance_after: balanceBefore + REFERRAL_BONUS,
      status: 'completed',
      metadata: { referred_user_id: referredUserId },
    }, { transaction: t });

    await referral.update({
      status: 'rewarded',
      reward_amount: REFERRAL_BONUS,
      rewarded_at: new Date(),
    }, { transaction: t });

    setImmediate(() => smsService.sendReferralReward(referrer.phone, REFERRAL_BONUS, referrer.id));

    logger.info(`Referral bonus paid: referrer=${referral.referrer_id} amount=${REFERRAL_BONUS} MWK`);
  });
};

// ─── Admin: Assign free bet ───────────────────────────────────────────────────

exports.assignFreeBet = async (userId, amount, expiryDays = 7, assignedBy) => {
  return sequelize.transaction(async (t) => {
    const expiresAt = new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000);

    const bonus = await UserBonus.create({
      user_id: userId,
      type: 'free_bet',
      bonus_amount: amount,
      required_wager: amount,  // Must wager the free bet amount once
      status: 'active',
      expires_at: expiresAt,
    }, { transaction: t });

    // Credit bonus wallet (free bet = bonus wallet, winnings withdrawable)
    await Wallet.update(
      { bonus_balance: sequelize.literal(`bonus_balance + ${amount}`) },
      { where: { user_id: userId }, transaction: t }
    );

    const user = await User.findByPk(userId, { transaction: t });
    setImmediate(() => smsService.sendBonusNotification(user.phone, amount, 'Free Bet', userId));

    logger.info(`Free bet assigned: user=${userId} amount=${amount} by admin=${assignedBy}`);
    return bonus;
  });
};
