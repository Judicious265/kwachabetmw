/**
 * PayChangu Payment Service
 * Handles bank payments and mobile money (Airtel/TNM) via PayChangu API
 * https://paychangu.com/documentation
 */

const axios = require('axios');
const crypto = require('crypto');
const logger = require('../../utils/logger');

const BASE_URL = process.env.PAYCHANGU_BASE_URL || 'https://api.paychangu.com';
const API_KEY = process.env.PAYCHANGU_API_KEY;
const WEBHOOK_SECRET = process.env.PAYCHANGU_WEBHOOK_SECRET;

const client = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
  timeout: 30000,
});

// ─── Initiate Checkout (Bank Transfer / Card) ─────────────────────────────────

exports.initiateCheckout = async ({
  amount, email, firstName, lastName,
  reference, callbackUrl, returnUrl, cancelUrl,
}) => {
  try {
    const res = await client.post('/payment', {
      amount: parseFloat(amount).toFixed(2),
      currency: 'MWK',
      email,
      first_name: firstName,
      last_name: lastName,
      callback_url: callbackUrl,
      return_url: returnUrl,
      cancel_url: cancelUrl,
      tx_ref: reference,
      title: 'Kwacha Bet Deposit',
      description: `Deposit to Kwacha Bet wallet - Ref: ${reference}`,
    });

    if (!res.data?.data?.checkout_url) {
      throw new Error('No checkout URL returned from PayChangu');
    }

    return {
      checkout_url: res.data.data.checkout_url,
      reference: res.data.data.tx_ref,
    };
  } catch (err) {
    logger.error('PayChangu initiateCheckout error:', err.response?.data || err.message);
    throw new Error('Payment gateway error. Please try again.');
  }
};

// ─── Initiate Mobile Money (Airtel / TNM) ────────────────────────────────────

exports.initiateMobileMoney = async ({
  amount, phone, reference, network, callbackUrl, returnUrl,
}) => {
  try {
    const res = await client.post('/mobile-money/collect', {
      amount: parseFloat(amount).toFixed(2),
      currency: 'MWK',
      phone_number: phone,
      network,                      // AIRTEL or TNM
      tx_ref: reference,
      callback_url: callbackUrl,
      return_url: returnUrl,
      title: 'Kwacha Bet Deposit',
      description: `Deposit MWK ${amount} to Kwacha Bet`,
    });

    return {
      checkout_url: res.data.data?.checkout_url || null,
      reference: res.data.data?.tx_ref || reference,
      instruction: res.data.data?.instruction || `Enter PIN on your ${network} prompt`,
    };
  } catch (err) {
    logger.error('PayChangu initiateMobileMoney error:', err.response?.data || err.message);
    throw new Error('Mobile money payment failed. Please try again.');
  }
};

// ─── Disburse (Withdrawal via Mobile Money) ───────────────────────────────────

exports.disburse = async ({ amount, phone, network, reference, narration }) => {
  try {
    const res = await client.post('/mobile-money/disburse', {
      amount: parseFloat(amount).toFixed(2),
      currency: 'MWK',
      phone_number: phone,
      network,
      tx_ref: reference,
      narration: narration || `Kwacha Bet withdrawal - ${reference}`,
    });

    const status = res.data.data?.status;
    return {
      success: status === 'success' || status === 'pending',
      provider_ref: res.data.data?.flw_ref || reference,
      status: res.data.data?.status,
    };
  } catch (err) {
    logger.error('PayChangu disburse error:', err.response?.data || err.message);
    return { success: false, error: err.response?.data?.message || 'Disbursement failed' };
  }
};

// ─── Verify Transaction ───────────────────────────────────────────────────────

exports.verifyTransaction = async (txRef) => {
  try {
    const res = await client.get(`/verify-payment/${txRef}`);
    const data = res.data.data;

    return {
      success: data.status === 'successful',
      amount: parseFloat(data.amount),
      currency: data.currency,
      reference: data.tx_ref,
      provider_ref: data.flw_ref,
      payment_type: data.payment_type,
    };
  } catch (err) {
    logger.error('PayChangu verifyTransaction error:', err.response?.data || err.message);
    return { success: false };
  }
};

// ─── Verify Webhook Signature ─────────────────────────────────────────────────

exports.verifyWebhookSignature = (rawBody, signature) => {
  const hash = crypto
    .createHmac('sha256', WEBHOOK_SECRET)
    .update(rawBody)
    .digest('hex');
  return hash === signature;
};

// ─── Parse Webhook Payload ────────────────────────────────────────────────────

exports.parseWebhook = (body) => {
  const { event, data } = body;

  if (event === 'charge.completed') {
    return {
      type: 'deposit_success',
      txRef: data.tx_ref,
      amount: parseFloat(data.amount),
      currency: data.currency,
      providerRef: data.flw_ref,
      phone: data.customer?.phone_number,
    };
  }

  if (event === 'transfer.completed') {
    return {
      type: 'withdrawal_success',
      txRef: data.reference,
      amount: parseFloat(data.amount),
      status: data.status,
    };
  }

  return { type: 'unknown', raw: body };
};
