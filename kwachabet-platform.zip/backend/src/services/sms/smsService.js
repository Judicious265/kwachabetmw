/**
 * SMS Service - Africa's Talking Integration
 * OTP delivery, win notifications, deposit/withdrawal confirmations
 * Includes delivery tracking and retry logic
 */

const axios = require('axios');
const qs = require('querystring');
const { SmsLog } = require('../../models');
const logger = require('../../utils/logger');

const BASE_URL = process.env.AT_BASE_URL || 'https://api.africastalking.com';
const API_KEY = process.env.AT_API_KEY;
const USERNAME = process.env.AT_USERNAME || 'kwachabet';
const SENDER_ID = process.env.AT_SENDER_ID || 'KwachaBet';

const client = axios.create({
  baseURL: BASE_URL,
  headers: {
    'apiKey': API_KEY,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
  },
  timeout: 15000,
});

// ─── SMS Templates ────────────────────────────────────────────────────────────

const TEMPLATES = {
  otp_registration: (otp) =>
    `Welcome to Kwacha Bet! Your verification code is: ${otp}. Valid for 5 minutes. Do not share.`,

  otp_withdrawal: (otp) =>
    `KwachaBet: Your withdrawal OTP is ${otp}. Valid for 5 mins. Never share this code.`,

  otp_login: (otp) =>
    `KwachaBet: Your login code is ${otp}. Expires in 5 mins.`,

  welcome: (name) =>
    `Hi ${name}! Welcome to Kwacha Bet - Malawi's #1 betting platform. Deposit now to start winning! kwachabet.mw`,

  deposit_confirmed: (amount, balance) =>
    `KwachaBet: Deposit of MWK ${formatAmount(amount)} received. Balance: MWK ${formatAmount(balance)}. Good luck!`,

  withdrawal_processing: (amount) =>
    `KwachaBet: Withdrawal of MWK ${formatAmount(amount)} is being processed. Funds arrive within 10 mins.`,

  withdrawal_completed: (amount) =>
    `KwachaBet: Withdrawal of MWK ${formatAmount(amount)} successful. Check your mobile money wallet.`,

  bet_won: (amount, balance) =>
    `Congratulations! You won MWK ${formatAmount(amount)} on KwachaBet! Your balance is now MWK ${formatAmount(balance)}. Keep winning!`,

  bonus_awarded: (amount, type) =>
    `KwachaBet: You've received a ${type} bonus of MWK ${formatAmount(amount)}! Log in to use it. T&Cs apply.`,

  referral_reward: (amount) =>
    `KwachaBet: You earned MWK ${formatAmount(amount)} referral bonus! Your friend joined and deposited.`,

  account_suspended: () =>
    `KwachaBet: Your account has been temporarily suspended. Contact support: support@kwachabet.mw`,
};

function formatAmount(n) {
  return parseFloat(n).toLocaleString('en-MW', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ─── Core Send Function ────────────────────────────────────────────────────────

async function sendSMS(phone, message, template = null, userId = null) {
  // Create log entry
  const smsLog = await SmsLog.create({
    user_id: userId,
    phone,
    message,
    template,
    status: 'pending',
  });

  try {
    const payload = qs.stringify({
      username: USERNAME,
      to: phone,
      message,
      from: SENDER_ID,
    });

    const res = await client.post('/version1/messaging', payload);
    const result = res.data.SMSMessageData?.Recipients?.[0];

    if (result?.status === 'Success') {
      await smsLog.update({
        status: 'sent',
        provider_id: result.messageId,
        cost: parseFloat(result.cost?.replace('MWK ', '') || 0),
        sent_at: new Date(),
      });
      logger.info(`SMS sent to ${phone}: ${template || 'custom'}`);
    } else {
      throw new Error(result?.status || 'Unknown SMS failure');
    }
  } catch (err) {
    await smsLog.update({
      status: 'failed',
      error_msg: err.message,
    });
    logger.error(`SMS failed to ${phone}:`, err.message);
    // Queue for retry if not OTP (OTPs expire anyway)
    if (template && !template.startsWith('otp_')) {
      await queueRetry(smsLog.id);
    }
  }

  return smsLog;
}

async function queueRetry(smsLogId) {
  try {
    const { smsQueue } = require('../../jobs/smsRetry');
    await smsQueue.add('retry', { smsLogId }, { delay: 60000, attempts: 3 });
  } catch (err) {
    logger.error('Failed to queue SMS retry:', err);
  }
}

// ─── Public API ───────────────────────────────────────────────────────────────

exports.sendOTP = async (phone, otp, purpose = 'registration', userId = null) => {
  const templateKey = `otp_${purpose}`;
  const template = TEMPLATES[templateKey] || TEMPLATES.otp_registration;
  return sendSMS(phone, template(otp), templateKey, userId);
};

exports.sendWelcome = async (phone, firstName, userId = null) => {
  return sendSMS(phone, TEMPLATES.welcome(firstName), 'welcome', userId);
};

exports.sendDepositConfirmation = async (phone, amount, balance, userId = null) => {
  return sendSMS(phone, TEMPLATES.deposit_confirmed(amount, balance), 'deposit_confirmed', userId);
};

exports.sendWithdrawalUpdate = async (phone, amount, status, userId = null) => {
  const msg = status === 'completed'
    ? TEMPLATES.withdrawal_completed(amount)
    : TEMPLATES.withdrawal_processing(amount);
  return sendSMS(phone, msg, `withdrawal_${status}`, userId);
};

exports.sendWinNotification = async (phone, amount, balance, userId = null) => {
  return sendSMS(phone, TEMPLATES.bet_won(amount, balance), 'bet_won', userId);
};

exports.sendBonusNotification = async (phone, amount, bonusType, userId = null) => {
  return sendSMS(phone, TEMPLATES.bonus_awarded(amount, bonusType), 'bonus_awarded', userId);
};

exports.sendReferralReward = async (phone, amount, userId = null) => {
  return sendSMS(phone, TEMPLATES.referral_reward(amount), 'referral_reward', userId);
};

// ─── Retry failed SMS ─────────────────────────────────────────────────────────

exports.retryFailedSMS = async (smsLogId) => {
  const log = await SmsLog.findByPk(smsLogId);
  if (!log || log.status === 'delivered' || log.retries >= 3) return;

  await log.increment('retries');
  return sendSMS(log.phone, log.message, log.template, log.user_id);
};

// ─── Delivery report webhook handler ─────────────────────────────────────────

exports.handleDeliveryReport = async (data) => {
  const { id: providerId, status } = data;
  await SmsLog.update(
    { status: status === 'Success' ? 'delivered' : 'failed' },
    { where: { provider_id: providerId } }
  );
};
