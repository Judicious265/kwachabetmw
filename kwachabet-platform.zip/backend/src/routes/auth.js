/**
 * Auth Routes - /api/v1/auth
 */
const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const authController = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  next();
};

router.post('/register/initiate', [
  body('phone').matches(/^\+265[89]\d{8}$/).withMessage('Valid Malawian phone required (+265)'),
  body('full_name').trim().isLength({ min: 2, max: 100 }),
  body('date_of_birth').isDate().withMessage('Valid date required'),
  body('password').isLength({ min: 8 }).withMessage('Password min 8 characters'),
], validate, authController.initiateRegistration);

router.post('/register/verify', [
  body('phone').matches(/^\+265[89]\d{8}$/),
  body('otp').isLength({ min: 6, max: 6 }).isNumeric(),
], validate, authController.verifyRegistration);

router.post('/login', [
  body('phone').matches(/^\+265[89]\d{8}$/),
  body('password').notEmpty(),
], validate, authController.login);

router.post('/pin/set', authenticate, [
  body('pin').isLength({ min: 4, max: 4 }).isNumeric(),
], validate, authController.setPin);

router.post('/pin/verify', authenticate, [
  body('pin').isLength({ min: 4, max: 4 }).isNumeric(),
], validate, authController.verifyPin);

router.post('/otp/withdrawal', authenticate, authController.requestWithdrawalOTP);

module.exports = router;
