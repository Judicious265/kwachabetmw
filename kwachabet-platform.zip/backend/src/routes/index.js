/**
 * Wallet Routes - /api/v1/wallet
 */
const express = require('express');
const { body } = require('express-validator');
const { authenticate, requirePinVerified } = require('../middleware/auth');
const walletController = require('../controllers/walletController');

const router = express.Router();
router.use(authenticate);

router.get('/balance', walletController.getBalance);
router.get('/transactions', walletController.getTransactions);

router.post('/deposit', [
  body('amount').isFloat({ min: 500 }),
  body('method').isIn(['airtel', 'mpamba', 'bank']),
  body('phone').optional().matches(/^\+265[89]\d{8}$/),
], walletController.initiateDeposit);

router.post('/withdraw', requirePinVerified, [
  body('amount').isFloat({ min: 500 }),
  body('method').isIn(['airtel', 'mpamba']),
  body('destination').matches(/^\+265[89]\d{8}$/),
  body('otp').isLength({ min: 6, max: 6 }).isNumeric(),
], walletController.requestWithdrawal);

module.exports = router;

/* ─────────────────────────────────────────────────────────────────────────── */

/**
 * Betting Routes - /api/v1/betting
 */
const bRouter = express.Router();
const bettingController = require('../controllers/bettingController');
bRouter.use(authenticate);

bRouter.post('/place', [
  body('selections').isArray({ min: 1, max: 20 }),
  body('stake').isFloat({ min: 50 }),
  body('use_bonus').optional().isBoolean(),
  body('is_live').optional().isBoolean(),
], bettingController.placeBet);

bRouter.get('/tickets', bettingController.getTickets);
bRouter.get('/tickets/:code', bettingController.getTicket);
bRouter.get('/check/:code', bettingController.checkTicket); // public

exports.bettingRouter = bRouter;

/* ─────────────────────────────────────────────────────────────────────────── */

/**
 * Odds Routes - /api/v1/odds
 */
const oRouter = express.Router();
const oddsService = require('../services/odds/oddsService');
const { cache } = require('../config/redis');

oRouter.get('/events', async (req, res) => {
  try {
    const { sport, status = 'upcoming' } = req.query;
    const { Event, Market } = require('../models');
    const where = { status };
    if (sport) where.sport_id = sport;
    const events = await Event.findAll({
      where,
      include: [{ model: Market, as: 'markets', where: { is_active: true }, required: false }],
      order: [['commence_time', 'ASC']],
      limit: 50,
    });
    res.json({ events });
  } catch { res.status(500).json({ error: 'Could not fetch events.' }); }
});

oRouter.get('/featured', async (req, res) => {
  try {
    const events = await oddsService.getFeaturedEvents();
    res.json({ events });
  } catch { res.status(500).json({ error: 'Could not fetch featured events.' }); }
});

oRouter.get('/sports', async (req, res) => {
  const { Sport } = require('../models');
  const sports = await Sport.findAll({ where: { is_active: true } });
  res.json({ sports });
});

exports.oddsRouter = oRouter;

/* ─────────────────────────────────────────────────────────────────────────── */

/**
 * Admin Routes - /api/v1/admin
 */
const aRouter = express.Router();
const { authenticate: auth, requireAdmin } = require('../middleware/auth');
const adminController = require('../controllers/adminController');
aRouter.use(auth, requireAdmin);

// Users
aRouter.get('/users', adminController.listUsers);
aRouter.get('/users/:id', adminController.getUserDetail);
aRouter.patch('/users/:id/suspend', adminController.suspendUser);
aRouter.patch('/users/:id/unsuspend', adminController.unsuspendUser);

// Tickets
aRouter.get('/tickets', adminController.listTickets);
aRouter.get('/tickets/stats', adminController.ticketStats);

// Finances
aRouter.get('/transactions', adminController.listTransactions);
aRouter.get('/withdrawals/pending', adminController.pendingWithdrawals);
aRouter.patch('/withdrawals/:id/approve', adminController.approveWithdrawal);
aRouter.patch('/withdrawals/:id/reject', adminController.rejectWithdrawal);

// Fraud
aRouter.get('/fraud/dashboard', adminController.fraudDashboard);
aRouter.patch('/fraud/flags/:id/resolve', adminController.resolveFraudFlag);
aRouter.post('/fraud/blacklist/device', adminController.blacklistDevice);

// Bonus
aRouter.get('/bonus/campaigns', adminController.listCampaigns);
aRouter.post('/bonus/campaigns', adminController.createCampaign);
aRouter.post('/bonus/free-bet', adminController.assignFreeBet);

// Dashboard
aRouter.get('/dashboard/stats', adminController.getDashboardStats);

exports.adminRouter = aRouter;

/* ─────────────────────────────────────────────────────────────────────────── */

/**
 * Webhook Routes - /webhooks/paychangu
 */
const wRouter = express.Router();
const paychangu = require('../services/payment/paychangu');
const walletCtrl = require('../controllers/walletController');
const logger = require('../utils/logger');

wRouter.post('/', async (req, res) => {
  try {
    const sig = req.headers['verif-hash'] || req.headers['x-paychangu-signature'];
    if (!paychangu.verifyWebhookSignature(req.body, sig)) {
      logger.warn('Invalid PayChangu webhook signature');
      return res.status(400).json({ error: 'Invalid signature' });
    }

    const payload = paychangu.parseWebhook(JSON.parse(req.body));
    logger.info(`Webhook received: ${payload.type} ref=${payload.txRef}`);

    if (payload.type === 'deposit_success') {
      const { Deposit } = require('../models');
      const deposit = await Deposit.findOne({ where: { id: payload.txRef } });
      if (deposit && deposit.status === 'pending') {
        await walletCtrl.creditWallet(deposit.id, payload.amount, payload.providerRef);
      }
    }

    if (payload.type === 'withdrawal_success') {
      const { Withdrawal } = require('../models');
      const withdrawal = await Withdrawal.findOne({ where: { id: payload.txRef } });
      if (withdrawal) {
        await withdrawal.update({ status: 'completed' });
        const { User } = require('../models');
        const user = await User.findByPk(withdrawal.user_id);
        const smsService = require('../services/sms/smsService');
        await smsService.sendWithdrawalUpdate(user.phone, withdrawal.amount, 'completed', user.id);
      }
    }

    res.json({ received: true });
  } catch (err) {
    logger.error('Webhook error:', err);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

exports.webhookRouter = wRouter;
