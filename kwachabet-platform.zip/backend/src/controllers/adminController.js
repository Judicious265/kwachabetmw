/**
 * Admin Controller
 * Full admin panel: users, tickets, finances, fraud, bonus management
 */

const { User, Ticket, TicketSelection, Transaction, Withdrawal, Deposit,
        FraudFlag, BlacklistedDevice, BonusCampaign, UserBonus, Wallet,
        AuditLog, Event } = require('../models');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const fraudService = require('../services/fraud/fraudService');
const bonusService = require('../services/bonus/bonusService');
const paychangu = require('../services/payment/paychangu');
const smsService = require('../services/sms/smsService');
const logger = require('../utils/logger');

// ─── Audit log helper ─────────────────────────────────────────────────────────

async function auditLog(adminId, action, entityType, entityId, details, ip) {
  await AuditLog.create({ admin_id: adminId, action, entity_type: entityType, entity_id: entityId, details, ip_address: ip });
}

// ─── Dashboard Stats ──────────────────────────────────────────────────────────

exports.getDashboardStats = async (req, res) => {
  try {
    const today = new Date(); today.setHours(0,0,0,0);
    const [
      totalUsers, newUsersToday, activeTickets,
      todayDeposits, todayWithdrawals, pendingWithdrawals,
      fraudFlags, totalWalletBalance,
    ] = await Promise.all([
      User.count(),
      User.count({ where: { created_at: { [Op.gte]: today } } }),
      Ticket.count({ where: { status: 'pending' } }),
      Transaction.sum('amount', { where: { type: 'deposit', created_at: { [Op.gte]: today }, status: 'completed' } }),
      Transaction.sum('amount', { where: { type: 'withdrawal', created_at: { [Op.gte]: today }, status: 'completed' } }),
      Withdrawal.count({ where: { status: { [Op.in]: ['pending', 'flagged'] } } }),
      FraudFlag.count({ where: { resolved: false } }),
      Wallet.sum('balance'),
    ]);

    res.json({
      users: { total: totalUsers, new_today: newUsersToday },
      bets: { active_tickets: activeTickets },
      finance: {
        deposits_today: todayDeposits || 0,
        withdrawals_today: todayWithdrawals || 0,
        pending_withdrawals: pendingWithdrawals,
        total_wallet_balance: totalWalletBalance || 0,
      },
      fraud: { open_flags: fraudFlags },
    });
  } catch (err) {
    logger.error('getDashboardStats:', err);
    res.status(500).json({ error: 'Could not load stats.' });
  }
};

// ─── User Management ──────────────────────────────────────────────────────────

exports.listUsers = async (req, res) => {
  const { page = 1, limit = 20, search, risk_min } = req.query;
  const where = {};
  if (search) where[Op.or] = [
    { phone: { [Op.iLike]: `%${search}%` } },
    { full_name: { [Op.iLike]: `%${search}%` } },
  ];
  if (risk_min) where.risk_score = { [Op.gte]: parseInt(risk_min) };

  const { count, rows } = await User.findAndCountAll({
    where,
    attributes: ['id','phone','full_name','risk_score','is_suspended','is_verified','created_at'],
    include: [{ model: Wallet, as: 'wallet', attributes: ['balance','bonus_balance'] }],
    order: [['created_at', 'DESC']],
    limit: Math.min(parseInt(limit), 100),
    offset: (page - 1) * limit,
  });

  res.json({ users: rows, total: count, page: parseInt(page) });
};

exports.getUserDetail = async (req, res) => {
  const user = await User.findByPk(req.params.id, {
    include: [
      { model: Wallet, as: 'wallet' },
      { model: Ticket, as: 'tickets', limit: 10, order: [['created_at', 'DESC']] },
      { model: Transaction, as: 'transactions', limit: 10, order: [['created_at', 'DESC']] },
      { model: FraudFlag, as: 'fraud_flags', where: { resolved: false }, required: false },
    ],
  });
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user });
};

exports.suspendUser = async (req, res) => {
  const { reason } = req.body;
  await User.update({ is_suspended: true, suspension_reason: reason }, { where: { id: req.params.id } });
  await auditLog(req.user.id, 'suspend_user', 'user', req.params.id, { reason }, req.ip);
  const user = await User.findByPk(req.params.id);
  await smsService.sendSMS(user.phone, 'KwachaBet: Your account has been suspended. Contact support@kwachabet.mw', 'account_suspended');
  res.json({ message: 'User suspended.' });
};

exports.unsuspendUser = async (req, res) => {
  await User.update({ is_suspended: false, suspension_reason: null }, { where: { id: req.params.id } });
  await auditLog(req.user.id, 'unsuspend_user', 'user', req.params.id, {}, req.ip);
  res.json({ message: 'User unsuspended.' });
};

// ─── Ticket Monitoring ────────────────────────────────────────────────────────

exports.listTickets = async (req, res) => {
  const { status, page = 1, limit = 30 } = req.query;
  const where = {};
  if (status) where.status = status;

  const { count, rows } = await Ticket.findAndCountAll({
    where,
    include: [
      { model: User, as: 'user', attributes: ['id','phone','full_name'] },
      { model: TicketSelection, as: 'selections', include: [{ model: Event, as: 'event' }] },
    ],
    order: [['created_at', 'DESC']],
    limit: Math.min(parseInt(limit), 100),
    offset: (page - 1) * limit,
  });

  res.json({ tickets: rows, total: count });
};

exports.ticketStats = async (req, res) => {
  const stats = await Ticket.findAll({
    attributes: ['status', [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
                 [sequelize.fn('SUM', sequelize.col('stake')), 'total_staked'],
                 [sequelize.fn('SUM', sequelize.col('actual_win')), 'total_paid']],
    group: ['status'],
    raw: true,
  });
  res.json({ stats });
};

// ─── Financial Control ────────────────────────────────────────────────────────

exports.listTransactions = async (req, res) => {
  const { type, status, page = 1, limit = 30 } = req.query;
  const where = {};
  if (type) where.type = type;
  if (status) where.status = status;

  const { count, rows } = await Transaction.findAndCountAll({
    where,
    include: [{ model: User, as: 'user', attributes: ['id','phone','full_name'] }],
    order: [['created_at', 'DESC']],
    limit: Math.min(parseInt(limit), 100),
    offset: (page - 1) * limit,
  });
  res.json({ transactions: rows, total: count });
};

exports.pendingWithdrawals = async (req, res) => {
  const withdrawals = await Withdrawal.findAll({
    where: { status: { [Op.in]: ['pending', 'flagged', 'manual_review'] } },
    include: [{ model: User, as: 'user', attributes: ['id','phone','full_name','risk_score'] }],
    order: [['created_at', 'ASC']],
  });
  res.json({ withdrawals });
};

exports.approveWithdrawal = async (req, res) => {
  return sequelize.transaction(async (t) => {
    const withdrawal = await Withdrawal.findByPk(req.params.id, { transaction: t, lock: true });
    if (!withdrawal) return res.status(404).json({ error: 'Not found.' });
    if (!['flagged', 'manual_review', 'pending'].includes(withdrawal.status)) {
      return res.status(400).json({ error: 'Cannot approve this withdrawal.' });
    }

    // Execute payout via PayChangu
    const result = await paychangu.disburse({
      amount: withdrawal.amount,
      phone: withdrawal.destination,
      network: withdrawal.payment_method === 'airtel' ? 'AIRTEL' : 'TNM',
      reference: withdrawal.id,
    });

    const newStatus = result.success ? 'completed' : 'failed';
    await withdrawal.update({ status: newStatus, approved_by: req.user.id, approved_at: new Date() }, { transaction: t });

    // Release locked funds
    const wallet = await Wallet.findOne({ where: { user_id: withdrawal.user_id }, transaction: t, lock: true });
    await wallet.update({
      locked_amount: Math.max(0, parseFloat(wallet.locked_amount) - parseFloat(withdrawal.amount)),
      balance: newStatus === 'completed'
        ? Math.max(0, parseFloat(wallet.balance) - parseFloat(withdrawal.amount))
        : wallet.balance,
    }, { transaction: t });

    await auditLog(req.user.id, 'approve_withdrawal', 'withdrawal', withdrawal.id, { amount: withdrawal.amount, result }, req.ip);

    const user = await User.findByPk(withdrawal.user_id);
    if (newStatus === 'completed') {
      await smsService.sendWithdrawalUpdate(user.phone, withdrawal.amount, 'completed', user.id);
    }

    res.json({ message: `Withdrawal ${newStatus}.`, status: newStatus });
  });
};

exports.rejectWithdrawal = async (req, res) => {
  const { reason } = req.body;
  const withdrawal = await Withdrawal.findByPk(req.params.id);
  if (!withdrawal) return res.status(404).json({ error: 'Not found.' });

  await withdrawal.update({ status: 'cancelled', admin_notes: reason });

  // Restore funds
  const wallet = await Wallet.findOne({ where: { user_id: withdrawal.user_id } });
  await wallet.update({
    locked_amount: Math.max(0, parseFloat(wallet.locked_amount) - parseFloat(withdrawal.amount)),
  });

  await auditLog(req.user.id, 'reject_withdrawal', 'withdrawal', withdrawal.id, { reason }, req.ip);
  res.json({ message: 'Withdrawal rejected and funds released.' });
};

// ─── Fraud Management ─────────────────────────────────────────────────────────

exports.fraudDashboard = async (req, res) => {
  const data = await fraudService.getFraudDashboard(req.query);
  res.json(data);
};

exports.resolveFraudFlag = async (req, res) => {
  const { notes } = req.body;
  await FraudFlag.update(
    { resolved: true, resolved_by: req.user.id, resolved_at: new Date(), admin_notes: notes },
    { where: { id: req.params.id } }
  );
  await auditLog(req.user.id, 'resolve_fraud_flag', 'fraud_flag', req.params.id, { notes }, req.ip);
  res.json({ message: 'Fraud flag resolved.' });
};

exports.blacklistDevice = async (req, res) => {
  const { fingerprint, ip_address, reason } = req.body;
  await BlacklistedDevice.upsert({ fingerprint, ip_address, reason, blocked_by: req.user.id });
  await auditLog(req.user.id, 'blacklist_device', 'device', null, { fingerprint, reason }, req.ip);
  res.json({ message: 'Device blacklisted.' });
};

// ─── Bonus Management ────────────────────────────────────────────────────────

exports.listCampaigns = async (req, res) => {
  const campaigns = await BonusCampaign.findAll({ order: [['created_at', 'DESC']] });
  res.json({ campaigns });
};

exports.createCampaign = async (req, res) => {
  const campaign = await BonusCampaign.create({ ...req.body, created_by: req.user.id });
  await auditLog(req.user.id, 'create_campaign', 'bonus_campaign', campaign.id, req.body, req.ip);
  res.status(201).json({ campaign });
};

exports.assignFreeBet = async (req, res) => {
  const { user_id, amount, expiry_days } = req.body;
  const bonus = await bonusService.assignFreeBet(user_id, amount, expiry_days, req.user.id);
  await auditLog(req.user.id, 'assign_free_bet', 'user_bonus', user_id, { amount }, req.ip);
  res.status(201).json({ message: 'Free bet assigned.', bonus });
};
