/**
 * Auth Controller
 * Handles registration, login, OTP verification, PIN management
 * Malawi-only: enforces +265 phone numbers and 18+ age
 */

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { User, Wallet, OtpCode, UserSession } = require('../models');
const smsService = require('../services/sms/smsService');
const fraudService = require('../services/fraud/fraudService');
const { cache } = require('../config/redis');
const logger = require('../utils/logger');
const { generateReferralCode, generateOTP } = require('../utils/helpers');

const MALAWI_REGEX = /^\+265[89]\d{8}$/;  // Airtel: +2659, TNM: +2658

// ─── Helpers ─────────────────────────────────────────────────────────────────

function signToken(userId, role = 'user') {
  return jwt.sign(
    { sub: userId, role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

function calcAge(dob) {
  const diff = Date.now() - new Date(dob).getTime();
  return Math.floor(diff / (365.25 * 24 * 60 * 60 * 1000));
}

// ─── Register: Step 1 - Submit details & send OTP ─────────────────────────────

exports.initiateRegistration = async (req, res) => {
  try {
    const { phone, full_name, date_of_birth, password, email } = req.body;

    // Validate Malawian phone
    if (!MALAWI_REGEX.test(phone)) {
      return res.status(400).json({
        error: 'Only Malawian phone numbers (+265) are accepted.',
      });
    }

    // Age verification — must be 18+
    if (calcAge(date_of_birth) < 18) {
      return res.status(403).json({
        error: 'You must be 18 or older to register on Kwacha Bet.',
      });
    }

    // Check duplicate phone
    const existing = await User.findOne({ where: { phone } });
    if (existing) {
      return res.status(409).json({ error: 'Phone number already registered.' });
    }

    // Store pending registration in Redis (5 minute TTL)
    const regKey = `reg:pending:${phone}`;
    await cache.set(regKey, {
      phone, full_name, date_of_birth, password, email,
    }, 300);

    // Generate and send OTP
    const otp = generateOTP(6);
    const otpHash = await bcrypt.hash(otp, 10);

    await OtpCode.create({
      phone,
      code_hash: otpHash,
      purpose: 'register',
      expires_at: new Date(Date.now() + 5 * 60 * 1000),
    });

    await smsService.sendOTP(phone, otp, 'registration');

    logger.info(`Registration OTP sent to ${phone}`);
    res.status(200).json({
      message: 'OTP sent to your phone. Enter it to complete registration.',
      expires_in: 300,
    });
  } catch (err) {
    logger.error('initiateRegistration error:', err);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
};

// ─── Register: Step 2 - Verify OTP & create account ─────────────────────────

exports.verifyRegistration = async (req, res) => {
  try {
    const { phone, otp, referral_code } = req.body;

    // Find valid OTP
    const otpRecord = await OtpCode.findOne({
      where: { phone, purpose: 'register', is_used: false },
      order: [['created_at', 'DESC']],
    });

    if (!otpRecord || new Date() > otpRecord.expires_at) {
      return res.status(400).json({ error: 'OTP expired or invalid. Request a new one.' });
    }

    // Max 3 attempts
    if (otpRecord.attempts >= 3) {
      return res.status(429).json({ error: 'Too many OTP attempts. Request a new OTP.' });
    }

    const valid = await bcrypt.compare(otp.toString(), otpRecord.code_hash);
    if (!valid) {
      await otpRecord.increment('attempts');
      return res.status(400).json({ error: 'Incorrect OTP.' });
    }

    // Get pending registration data
    const regData = await cache.get(`reg:pending:${phone}`);
    if (!regData) {
      return res.status(400).json({ error: 'Registration session expired. Start again.' });
    }

    // Create user + wallet in a transaction
    const { sequelize } = require('../config/database');
    const result = await sequelize.transaction(async (t) => {
      const passwordHash = await bcrypt.hash(regData.password, parseInt(process.env.BCRYPT_ROUNDS) || 12);

      // Find referrer if code provided
      let referrerId = null;
      if (referral_code) {
        const referrer = await User.findOne({ where: { referral_code } });
        if (referrer) referrerId = referrer.id;
      }

      const user = await User.create({
        phone,
        full_name: regData.full_name,
        date_of_birth: regData.date_of_birth,
        email: regData.email,
        password_hash: passwordHash,
        is_verified: true,
        referral_code: generateReferralCode(),
        referred_by: referrerId,
      }, { transaction: t });

      const wallet = await Wallet.create({
        user_id: user.id,
        balance: 0,
        bonus_balance: 0,
      }, { transaction: t });

      // Mark OTP used
      await otpRecord.update({ is_used: true }, { transaction: t });

      // Create referral record
      if (referrerId) {
        const { Referral } = require('../models');
        await Referral.create({
          referrer_id: referrerId,
          referred_id: user.id,
        }, { transaction: t });
      }

      return { user, wallet };
    });

    // Apply welcome bonus
    const bonusService = require('../services/bonus/bonusService');
    // Bonus applied on first deposit, not at registration

    // Clean up
    await cache.del(`reg:pending:${phone}`);

    // Send welcome SMS
    await smsService.sendWelcome(phone, result.user.full_name.split(' ')[0]);

    const token = signToken(result.user.id);

    logger.info(`New user registered: ${result.user.id} (${phone})`);

    res.status(201).json({
      message: 'Account created successfully! Welcome to Kwacha Bet.',
      token,
      user: {
        id: result.user.id,
        phone: result.user.phone,
        full_name: result.user.full_name,
        referral_code: result.user.referral_code,
      },
    });
  } catch (err) {
    logger.error('verifyRegistration error:', err);
    res.status(500).json({ error: 'Verification failed. Please try again.' });
  }
};

// ─── Login ────────────────────────────────────────────────────────────────────

exports.login = async (req, res) => {
  try {
    const { phone, password } = req.body;
    const ip = req.ip || req.headers['x-forwarded-for'];
    const deviceFingerprint = req.headers['x-device-fingerprint'];

    const user = await User.findOne({ where: { phone } });
    if (!user) {
      return res.status(401).json({ error: 'Invalid phone number or password.' });
    }

    if (user.is_suspended) {
      return res.status(403).json({
        error: 'Account suspended. Contact support at support@kwachabet.mw',
      });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid phone number or password.' });
    }

    // Fraud: check device/IP
    await fraudService.checkLoginEvent(user, ip, deviceFingerprint);

    // Create session
    await UserSession.create({
      user_id: user.id,
      device_fingerprint: deviceFingerprint,
      ip_address: ip,
      user_agent: req.headers['user-agent'],
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    });

    await user.update({ last_login_at: new Date(), last_login_ip: ip });

    const token = signToken(user.id, user.is_admin ? 'admin' : 'user');

    res.json({
      token,
      user: {
        id: user.id,
        phone: user.phone,
        full_name: user.full_name,
        is_admin: user.is_admin || false,
      },
    });
  } catch (err) {
    logger.error('login error:', err);
    res.status(500).json({ error: 'Login failed.' });
  }
};

// ─── Set / Verify PIN ─────────────────────────────────────────────────────────

exports.setPin = async (req, res) => {
  try {
    const { pin } = req.body;
    const userId = req.user.id;

    if (!/^\d{4}$/.test(pin)) {
      return res.status(400).json({ error: 'PIN must be exactly 4 digits.' });
    }

    const pinHash = await bcrypt.hash(pin, 10);
    await User.update({ pin_hash: pinHash }, { where: { id: userId } });

    res.json({ message: 'PIN set successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to set PIN.' });
  }
};

exports.verifyPin = async (req, res) => {
  try {
    const { pin } = req.body;
    const user = await User.findByPk(req.user.id);

    if (!user.pin_hash) {
      return res.status(400).json({ error: 'No PIN set. Please set a PIN first.' });
    }

    const valid = await bcrypt.compare(pin.toString(), user.pin_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Incorrect PIN.' });
    }

    // Issue a short-lived PIN-verified token
    const pinToken = jwt.sign(
      { sub: user.id, scope: 'pin_verified' },
      process.env.JWT_SECRET,
      { expiresIn: '5m' }
    );

    res.json({ pin_token: pinToken, expires_in: 300 });
  } catch (err) {
    res.status(500).json({ error: 'PIN verification failed.' });
  }
};

// ─── Request OTP for withdrawal ───────────────────────────────────────────────

exports.requestWithdrawalOTP = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id);
    const otp = generateOTP(6);
    const otpHash = await bcrypt.hash(otp, 10);

    await OtpCode.create({
      phone: user.phone,
      code_hash: otpHash,
      purpose: 'withdrawal',
      expires_at: new Date(Date.now() + 5 * 60 * 1000),
    });

    await smsService.sendOTP(user.phone, otp, 'withdrawal');
    res.json({ message: 'OTP sent for withdrawal verification.' });
  } catch (err) {
    res.status(500).json({ error: 'Could not send OTP.' });
  }
};
