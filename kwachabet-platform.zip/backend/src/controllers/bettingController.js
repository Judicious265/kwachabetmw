/**
 * Betting Engine Controller
 * Handles single bets, accumulators, live betting, ticket management
 * Tax: 20% withholding tax on winnings in Malawi
 */

const { Ticket, TicketSelection, Market, Event, Wallet, Transaction, User } = require('../models');
const fraudService = require('../services/fraud/fraudService');
const bonusService = require('../services/bonus/bonusService');
const smsService = require('../services/sms/smsService');
const { sequelize } = require('../config/database');
const { cache } = require('../config/redis');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

const TAX_RATE = 0.20;         // 20% withholding tax on winnings
const MIN_STAKE = 50;          // MWK
const MAX_STAKE = 5000000;     // MWK 5M
const MAX_SELECTIONS = 20;     // Max legs in accumulator
const MAX_PAYOUT = 10000000;   // MWK 10M max payout

function generateTicketCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'KB-';
  for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

// ─── Place Bet ────────────────────────────────────────────────────────────────

exports.placeBet = async (req, res) => {
  try {
    const { selections, stake, use_bonus = false, is_live = false } = req.body;
    const userId = req.user.id;

    // Validate
    if (!selections || selections.length === 0) {
      return res.status(400).json({ error: 'At least one selection is required.' });
    }
    if (selections.length > MAX_SELECTIONS) {
      return res.status(400).json({ error: `Maximum ${MAX_SELECTIONS} selections per ticket.` });
    }
    if (stake < MIN_STAKE || stake > MAX_STAKE) {
      return res.status(400).json({
        error: `Stake must be between MWK ${MIN_STAKE} and MWK ${MAX_STAKE.toLocaleString()}.`,
      });
    }

    const user = await User.findByPk(userId);
    if (user.is_suspended) {
      return res.status(403).json({ error: 'Account suspended. Betting is not available.' });
    }

    // Fraud: unusual pattern check
    const fraudCheck = await fraudService.checkBettingPattern(userId, selections, stake);
    if (fraudCheck.blocked) {
      return res.status(403).json({ error: 'Bet blocked by security policy. Contact support.' });
    }

    // Validate all selections and fetch current odds
    const validatedSelections = [];
    let totalOdds = 1.0;

    for (const sel of selections) {
      const market = await Market.findOne({
        where: {
          id: sel.market_id,
          is_active: true,
          outcome: sel.selection,
        },
        include: [{ model: Event, as: 'event' }],
      });

      if (!market) {
        return res.status(400).json({
          error: `Market not available for selection: ${sel.selection}`,
        });
      }

      if (market.event.status === 'finished' || market.event.status === 'cancelled') {
        return res.status(400).json({
          error: `Event "${market.event.home_team} vs ${market.event.away_team}" is no longer available.`,
        });
      }

      if (is_live && market.event.status !== 'live') {
        return res.status(400).json({ error: 'Live betting only available for live events.' });
      }

      if (!is_live && market.event.status === 'live') {
        return res.status(400).json({
          error: 'Event is live. Use live betting for this market.',
        });
      }

      totalOdds *= parseFloat(market.odds);
      validatedSelections.push({ market, selection: sel.selection });
    }

    totalOdds = parseFloat(totalOdds.toFixed(3));

    // Check max payout
    const potentialWin = parseFloat((stake * totalOdds).toFixed(2));
    if (potentialWin > MAX_PAYOUT) {
      return res.status(400).json({
        error: `Potential payout exceeds maximum of MWK ${MAX_PAYOUT.toLocaleString()}. Reduce your stake.`,
      });
    }

    // Place bet in a database transaction
    const result = await sequelize.transaction(async (t) => {
      const wallet = await Wallet.findOne({
        where: { user_id: userId },
        transaction: t,
        lock: true,
      });

      const available = parseFloat(wallet.balance) - parseFloat(wallet.locked_amount);
      let actualStake = stake;
      let bonusStake = 0;

      // Check bonus wallet usage
      if (use_bonus && parseFloat(wallet.bonus_balance) > 0) {
        const bonusUsable = await bonusService.getUsableBonusForBet(userId, totalOdds, t);
        bonusStake = Math.min(bonusUsable, stake);
        actualStake = stake - bonusStake;
      }

      if (actualStake > available) {
        throw new Error('Insufficient balance.');
      }

      // Deduct stake
      const balanceBefore = parseFloat(wallet.balance);
      await wallet.update({
        balance: balanceBefore - actualStake,
        bonus_balance: use_bonus
          ? Math.max(0, parseFloat(wallet.bonus_balance) - bonusStake)
          : wallet.bonus_balance,
        locked_amount: parseFloat(wallet.locked_amount) + actualStake,
      }, { transaction: t });

      // Create transaction record for stake
      await Transaction.create({
        user_id: userId,
        wallet_id: wallet.id,
        type: 'bet_stake',
        amount: -stake,
        balance_before: balanceBefore,
        balance_after: balanceBefore - actualStake,
        status: 'completed',
        metadata: { total_odds: totalOdds, selections: selections.length },
      }, { transaction: t });

      // Create ticket
      const ticket = await Ticket.create({
        user_id: userId,
        ticket_code: generateTicketCode(),
        type: validatedSelections.length === 1 ? 'single' : (is_live ? 'live' : 'accumulator'),
        stake: actualStake,
        bonus_stake: bonusStake,
        total_odds: totalOdds,
        potential_win: potentialWin,
        is_live,
        status: 'pending',
      }, { transaction: t });

      // Create selections
      await TicketSelection.bulkCreate(
        validatedSelections.map(({ market, selection }) => ({
          ticket_id: ticket.id,
          event_id: market.event_id,
          market_id: market.id,
          market_type: market.market_type,
          selection,
          odds: parseFloat(market.odds),
          status: 'pending',
        })),
        { transaction: t }
      );

      // Update bonus wagering progress
      if (use_bonus && bonusStake > 0) {
        await bonusService.recordWager(userId, stake, t);
      }

      return ticket;
    });

    logger.info(`Bet placed: ticket=${result.ticket_code} user=${userId} stake=${stake} odds=${totalOdds}`);

    res.status(201).json({
      message: 'Bet placed successfully!',
      ticket: {
        id: result.id,
        ticket_code: result.ticket_code,
        stake,
        total_odds: totalOdds,
        potential_win: potentialWin,
        status: 'pending',
      },
    });
  } catch (err) {
    if (err.message === 'Insufficient balance.') {
      return res.status(400).json({ error: err.message });
    }
    logger.error('placeBet error:', err);
    res.status(500).json({ error: 'Failed to place bet. Please try again.' });
  }
};

// ─── Get User Tickets ─────────────────────────────────────────────────────────

exports.getTickets = async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const offset = (page - 1) * limit;
    const where = { user_id: req.user.id };
    if (status) where.status = status;

    const { count, rows } = await Ticket.findAndCountAll({
      where,
      include: [{
        model: TicketSelection,
        as: 'selections',
        include: [{ model: Event, as: 'event' }],
      }],
      order: [['created_at', 'DESC']],
      limit: Math.min(parseInt(limit), 50),
      offset: parseInt(offset),
    });

    res.json({
      tickets: rows,
      pagination: { total: count, page: parseInt(page), pages: Math.ceil(count / limit) },
    });
  } catch (err) {
    res.status(500).json({ error: 'Could not retrieve tickets.' });
  }
};

// ─── Get Single Ticket ────────────────────────────────────────────────────────

exports.getTicket = async (req, res) => {
  try {
    const ticket = await Ticket.findOne({
      where: { ticket_code: req.params.code.toUpperCase(), user_id: req.user.id },
      include: [{
        model: TicketSelection,
        as: 'selections',
        include: [
          { model: Event, as: 'event' },
          { model: Market, as: 'market' },
        ],
      }],
    });

    if (!ticket) return res.status(404).json({ error: 'Ticket not found.' });

    res.json({ ticket });
  } catch (err) {
    res.status(500).json({ error: 'Could not retrieve ticket.' });
  }
};

// ─── Settle Bet (called by bet settler job) ───────────────────────────────────

exports.settleBet = async (ticketId) => {
  return sequelize.transaction(async (t) => {
    const ticket = await Ticket.findByPk(ticketId, {
      include: [{ model: TicketSelection, as: 'selections' }],
      transaction: t,
      lock: true,
    });

    if (!ticket || ticket.status !== 'pending') return null;

    // Determine outcome
    const selStatuses = ticket.selections.map(s => s.status);
    let ticketStatus;

    if (selStatuses.includes('void')) {
      // Recalculate odds without voided legs
      ticketStatus = selStatuses.every(s => s === 'void') ? 'cancelled' : 'pending';
    } else if (selStatuses.every(s => s === 'won')) {
      ticketStatus = 'won';
    } else if (selStatuses.includes('lost')) {
      ticketStatus = 'lost';
    } else {
      return null; // Still pending
    }

    await ticket.update({ status: ticketStatus, settled_at: new Date() }, { transaction: t });

    const user = await User.findByPk(ticket.user_id);
    const wallet = await Wallet.findOne({ where: { user_id: ticket.user_id }, transaction: t, lock: true });

    // Release locked funds
    await wallet.update({
      locked_amount: Math.max(0, parseFloat(wallet.locked_amount) - parseFloat(ticket.stake)),
    }, { transaction: t });

    if (ticketStatus === 'won') {
      const grossWin = parseFloat(ticket.potential_win);
      const tax = parseFloat((grossWin * TAX_RATE).toFixed(2));
      const netWin = parseFloat((grossWin - tax).toFixed(2));
      const balanceBefore = parseFloat(wallet.balance);

      await wallet.update({ balance: balanceBefore + netWin }, { transaction: t });
      await ticket.update({ actual_win: netWin, tax_deducted: tax }, { transaction: t });

      await Transaction.create({
        user_id: ticket.user_id,
        wallet_id: wallet.id,
        type: 'bet_win',
        amount: netWin,
        balance_before: balanceBefore,
        balance_after: balanceBefore + netWin,
        status: 'completed',
        metadata: { ticket_id: ticket.id, gross_win: grossWin, tax },
      }, { transaction: t });

      // Send win SMS
      await smsService.sendWinNotification(user.phone, netWin, balanceBefore + netWin);

      logger.info(`Ticket won: ${ticket.ticket_code} net_win=${netWin} MWK`);
    } else if (ticketStatus === 'cancelled') {
      // Refund stake
      const balanceBefore = parseFloat(wallet.balance);
      await wallet.update({ balance: balanceBefore + parseFloat(ticket.stake) }, { transaction: t });
      await Transaction.create({
        user_id: ticket.user_id,
        wallet_id: wallet.id,
        type: 'bet_refund',
        amount: parseFloat(ticket.stake),
        balance_before: balanceBefore,
        balance_after: balanceBefore + parseFloat(ticket.stake),
        status: 'completed',
        metadata: { ticket_id: ticket.id, reason: 'void' },
      }, { transaction: t });
    }

    return ticket;
  });
};

// ─── Bet Check (public - verify ticket by code) ───────────────────────────────

exports.checkTicket = async (req, res) => {
  try {
    const ticket = await Ticket.findOne({
      where: { ticket_code: req.params.code.toUpperCase() },
      include: [{ model: TicketSelection, as: 'selections', include: [{ model: Event, as: 'event' }] }],
      attributes: ['ticket_code','type','stake','total_odds','potential_win','actual_win','status','created_at','settled_at'],
    });

    if (!ticket) return res.status(404).json({ error: 'Ticket not found.' });

    res.json({ ticket });
  } catch (err) {
    res.status(500).json({ error: 'Could not check ticket.' });
  }
};
