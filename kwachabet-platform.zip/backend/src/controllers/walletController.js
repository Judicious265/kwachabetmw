/**
 * Wallet Controller
 * Handles deposits (PayChangu/Airtel/TNM), withdrawals, balance queries
 * All amounts in Malawian Kwacha (MWK)
 */

const { Wallet, Transaction, Deposit, Withdrawal, User, OtpCode } = require('../models');
const paychangu = require('../services/payment/paychangu');
const fraudService = require('../services/fraud/fraudService');
const smsService = require('../services/sms/smsService');
const bonusService = require('../services/bonus/bonusService');
const { cache } = require('../config/redis');
const logger = require('../utils/logger');
const bcrypt = require('bcryptjs');
const { sequelize } = require('../config/database');

const MIN_DEPOSIT = parseFloat(process.env.MIN_DEPOSIT) || 500;
const MIN_WITHDRAWAL = parseFloat(process.env.MIN_WITHDRAWAL) || 500;
const AUTO_WITHDRAWAL_LIMIT = parseFloat(process.env.AUTO_WITHDRAWAL_LIMIT) || 1000000;

// ─── Get Wallet Balance ───────────────────────────────────────────────────────

exports.getBalance = async (req, res) => {
  try {
    const wallet = await Wallet.findOne({
      where: { user_id: req.user.id },
      attributes: ['id','balance','bonus_balance','locked_amount','currency','updated_at'],
    });

    if (!wallet) return res.status(404).json({ error: 'Wallet not found.' });

    res.json({
      balance: parseFloat(wallet.balance),
      bonus_balance: parseFloat(wallet.bonus_balance),
      locked_amount: parseFloat(wallet.locked_amount),
      available: parseFloat(wallet.balance) - parseFloat(wallet.locked_amount),
      currency: wallet.currency,
      updated_at: wallet.updated_at,
    });
  } catch (err) {
    logger.error('getBalance error:', err);
    res.status(500).json({ error: 'Could not retrieve balance.' });
  }
};

// ─── Initiate Deposit (PayChangu / Airtel / TNM) ──────────────────────────────

exports.initiateDeposit = async (req, res) => {
  try {
    const { amount, method, phone } = req.body;
    const userId = req.user.id;
    const user = await User.findByPk(userId);

    if (amount < MIN_DEPOSIT) {
      return res.status(400).json({ error: `Minimum deposit is MWK ${MIN_DEPOSIT.toLocaleString()}.` });
    }

    const deposit = await Deposit.create({
      user_id: userId,
      amount,
      payment_method: method,
      phone_used: phone || user.phone,
      status: 'pending',
    });

    let checkoutData;

    if (method === 'airtel' || method === 'mpamba') {
      // Mobile money via PayChangu
      checkoutData = await paychangu.initiateMobileMoney({
        amount,
        phone: phone || user.phone,
        reference: deposit.id,
        network: method === 'airtel' ? 'AIRTEL' : 'TNM',
        callbackUrl: `${process.env.API_BASE_URL}/webhooks/paychangu`,
        returnUrl: `${process.env.FRONTEND_URL}/wallet/deposit/success`,
      });
    } else if (method === 'bank') {
      checkoutData = await paychangu.initiateCheckout({
        amount,
        email: user.email,
        firstName: user.full_name.split(' ')[0],
        lastName: user.full_name.split(' ').slice(1).join(' '),
        reference: deposit.id,
        callbackUrl: `${process.env.API_BASE_URL}/webhooks/paychangu`,
        returnUrl: `${process.env.FRONTEND_URL}/wallet/deposit/success`,
        cancelUrl: `${process.env.FRONTEND_URL}/wallet/deposit/cancel`,
      });
    } else {
      return res.status(400).json({ error: 'Invalid payment method.' });
    }

    await deposit.update({
      provider_ref: checkoutData.reference,
      checkout_url: checkoutData.checkout_url,
    });

    res.status(201).json({
      deposit_id: deposit.id,
      checkout_url: checkoutData.checkout_url,
      amount,
      method,
      status: 'pending',
      message: method === 'bank'
        ? 'Redirecting to secure payment page...'
        : `A payment prompt will be sent to ${phone || user.phone}`,
    });
  } catch (err) {
    logger.error('initiateDeposit error:', err);
    res.status(500).json({ error: 'Deposit initiation failed.' });
  }
};

// ─── Credit Wallet (called by webhook handler) ────────────────────────────────

exports.creditWallet = async (depositId, amount, providerRef) => {
  return sequelize.transaction(async (t) => {
    const deposit = await Deposit.findByPk(depositId, { transaction: t, lock: true });
    if (!deposit || deposit.status !== 'pending') {
      throw new Error('Deposit not found or already processed');
    }

    const wallet = await Wallet.findOne({
      where: { user_id: deposit.user_id },
      transaction: t,
      lock: true,
    });

    const balanceBefore = parseFloat(wallet.balance);
    const newBalance = balanceBefore + parseFloat(amount);

    await wallet.update({ balance: newBalance }, { transaction: t });

    const txn = await Transaction.create({
      user_id: deposit.user_id,
      wallet_id: wallet.id,
      type: 'deposit',
      amount,
      balance_before: balanceBefore,
      balance_after: newBalance,
      reference: providerRef,
      payment_method: deposit.payment_method,
      status: 'completed',
    }, { transaction: t });

    await deposit.update({
      status: 'completed',
      transaction_id: txn.id,
      provider_ref: providerRef,
    }, { transaction: t });

    const user = await User.findByPk(deposit.user_id);

    // Apply welcome bonus on first deposit
    await bonusService.applyWelcomeBonus(deposit.user_id, amount, t);

    // Send confirmation SMS
    await smsService.sendDepositConfirmation(user.phone, amount, newBalance);

    logger.info(`Wallet credited: user=${deposit.user_id} amount=${amount} MWK balance=${newBalance}`);

    return { txn, newBalance };
  });
};

// ─── Request Withdrawal ───────────────────────────────────────────────────────

exports.requestWithdrawal = async (req, res) => {
  try {
    const { amount, method, destination, otp } = req.body;
    const userId = req.user.id;
    const user = await User.findByPk(userId);

    // Verify OTP
    const otpRecord = await OtpCode.findOne({
      where: { phone: user.phone, purpose: 'withdrawal', is_used: false },
      order: [['created_at', 'DESC']],
    });

    if (!otpRecord || new Date() > otpRecord.expires_at) {
      return res.status(400).json({ error: 'OTP expired. Request a new one.' });
    }

    const validOtp = await bcrypt.compare(otp.toString(), otpRecord.code_hash);
    if (!validOtp) {
      await otpRecord.increment('attempts');
      return res.status(400).json({ error: 'Incorrect OTP.' });
    }
    await otpRecord.update({ is_used: true });

    if (amount < MIN_WITHDRAWAL) {
      return res.status(400).json({ error: `Minimum withdrawal is MWK ${MIN_WITHDRAWAL.toLocaleString()}.` });
    }

    const wallet = await Wallet.findOne({ where: { user_id: userId } });
    const available = parseFloat(wallet.balance) - parseFloat(wallet.locked_amount);

    if (amount > available) {
      return res.status(400).json({ error: 'Insufficient balance.' });
    }

    // Fraud scoring
    const fraudResult = await fraudService.scoreWithdrawal(userId, amount, user);
    const isAuto = amount < AUTO_WITHDRAWAL_LIMIT && fraudResult.score < 70;

    const withdrawal = await Withdrawal.create({
      user_id: userId,
      amount,
      payment_method: method,
      destination,
      status: isAuto ? 'processing' : 'flagged',
      is_auto: isAuto,
      fraud_score: fraudResult.score,
    });

    if (isAuto) {
      // Queue for automatic processing
      const { withdrawalQueue } = require('../jobs/withdrawalProcessor');
      await withdrawalQueue.add('process', { withdrawalId: withdrawal.id }, {
        delay: 5000, // 5 second delay for fraud checks
        attempts: 3,
      });
    } else {
      // Notify admin for manual review
      await fraudService.flagWithdrawal(userId, withdrawal.id, fraudResult);
      logger.warn(`Withdrawal flagged for manual review: ${withdrawal.id} (score: ${fraudResult.score})`);
    }

    // Lock funds
    await wallet.update({
      locked_amount: sequelize.literal(`locked_amount + ${amount}`),
    });

    res.status(201).json({
      withdrawal_id: withdrawal.id,
      amount,
      status: withdrawal.status,
      message: isAuto
        ? 'Withdrawal processing. Funds will arrive within minutes.'
        : 'Withdrawal flagged for manual review. We will process within 24 hours.',
    });
  } catch (err) {
    logger.error('requestWithdrawal error:', err);
    res.status(500).json({ error: 'Withdrawal failed. Please try again.' });
  }
};

// ─── Transaction History ──────────────────────────────────────────────────────

exports.getTransactions = async (req, res) => {
  try {
    const { page = 1, limit = 20, type } = req.query;
    const offset = (page - 1) * limit;
    const where = { user_id: req.user.id };
    if (type) where.type = type;

    const { count, rows } = await Transaction.findAndCountAll({
      where,
      order: [['created_at', 'DESC']],
      limit: Math.min(parseInt(limit), 50),
      offset: parseInt(offset),
      attributes: ['id','type','amount','balance_before','balance_after',
                   'reference','payment_method','status','created_at'],
    });

    res.json({
      transactions: rows,
      pagination: {
        total: count,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(count / limit),
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Could not retrieve transactions.' });
  }
};
