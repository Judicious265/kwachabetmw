/**
 * Odds Poller Job
 * Polls the-odds-api every 2 minutes, broadcasts via WebSocket
 */
const cron = require('node-cron');
const oddsService = require('../services/odds/oddsService');
const logger = require('../utils/logger');

// Poll every 2 minutes
cron.schedule('*/2 * * * *', async () => {
  try {
    logger.debug('Polling odds...');
    const events = await oddsService.fetchAllOdds();
    if (oddsService.broadcastOddsUpdate) {
      oddsService.broadcastOddsUpdate(events);
    }
    logger.debug(`Odds updated: ${events.length} events`);
  } catch (err) {
    logger.error('Odds poller error:', err.message);
  }
});

module.exports = {};
