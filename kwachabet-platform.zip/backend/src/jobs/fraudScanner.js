/**
 * Fraud Scanner - Runs hourly risk rescoring on active users
 */
const cron = require('node-cron');
const { User, Ticket, Withdrawal } = require('../models');
const { Op } = require('sequelize');
const fraudService = require('../services/fraud/fraudService');
const logger = require('../utils/logger');

async function runFraudScan() {
  logger.info('Running scheduled fraud scan...');
  try {
    // Find users with recent activity in last 24h
    const activeUsers = await User.findAll({
      where: {
        last_login_at: { [Op.gte]: new Date(Date.now() - 24 * 60 * 60 * 1000) },
        is_suspended: false,
      },
      attributes: ['id', 'phone', 'risk_score', 'last_login_ip'],
      limit: 500,
    });

    let flagged = 0;
    for (const user of activeUsers) {
      try {
        const result = await fraudService.scoreWithdrawal(user.id, 0, user);
        if (result.score >= 70) {
          for (const rule of result.triggeredRules) {
            await fraudService.createFlag(user.id, rule.code, { scan: 'scheduled' }, rule.severity);
          }
          flagged++;
        }
      } catch (err) {
        logger.error(`Fraud scan error for user ${user.id}:`, err.message);
      }
    }

    logger.info(`Fraud scan complete: ${activeUsers.length} users scanned, ${flagged} flagged`);
  } catch (err) {
    logger.error('Fraud scanner error:', err);
  }
}

// Run every hour
cron.schedule('0 * * * *', runFraudScan);

module.exports = { runFraudScan };
