/**
 * Withdrawal Processor - Bull Queue
 * Auto-processes approved withdrawals via PayChangu
 */
const Bull = require('bull');
const { Withdrawal, Wallet, User, Transaction } = require('../models');
const paychangu = require('../services/payment/paychangu');
const smsService = require('../services/sms/smsService');
const { sequelize } = require('../config/database');
const logger = require('../utils/logger');

const withdrawalQueue = new Bull('withdrawals', {
  redis: process.env.REDIS_URL,
  defaultJobOptions: { attempts: 3, backoff: { type: 'exponential', delay: 5000 } },
});

withdrawalQueue.process('process', async (job) => {
  const { withdrawalId } = job.data;
  logger.info(`Processing withdrawal: ${withdrawalId}`);

  return sequelize.transaction(async (t) => {
    const withdrawal = await Withdrawal.findByPk(withdrawalId, { transaction: t, lock: true });
    if (!withdrawal || withdrawal.status !== 'processing') {
      return { skipped: true };
    }

    const user = await User.findByPk(withdrawal.user_id);
    const wallet = await Wallet.findOne({ where: { user_id: withdrawal.user_id }, transaction: t, lock: true });

    // Check balance
    const available = parseFloat(wallet.balance) - parseFloat(wallet.locked_amount) + parseFloat(withdrawal.amount);
    if (available < parseFloat(withdrawal.amount)) {
      await withdrawal.update({ status: 'failed', admin_notes: 'Insufficient balance at processing time' }, { transaction: t });
      return { failed: true };
    }

    // Execute payout
    const result = await paychangu.disburse({
      amount: withdrawal.amount,
      phone: withdrawal.destination,
      network: withdrawal.payment_method === 'airtel' ? 'AIRTEL' : 'TNM',
      reference: withdrawal.id,
      narration: `KwachaBet withdrawal for ${user.phone}`,
    });

    const newStatus = result.success ? 'completed' : 'failed';

    await withdrawal.update({ status: newStatus }, { transaction: t });

    // Debit wallet and release lock
    await wallet.update({
      balance: newStatus === 'completed'
        ? Math.max(0, parseFloat(wallet.balance) - parseFloat(withdrawal.amount))
        : wallet.balance,
      locked_amount: Math.max(0, parseFloat(wallet.locked_amount) - parseFloat(withdrawal.amount)),
    }, { transaction: t });

    if (newStatus === 'completed') {
      const balanceBefore = parseFloat(wallet.balance);
      await Transaction.create({
        user_id: withdrawal.user_id,
        wallet_id: wallet.id,
        type: 'withdrawal',
        amount: -parseFloat(withdrawal.amount),
        balance_before: balanceBefore,
        balance_after: balanceBefore - parseFloat(withdrawal.amount),
        reference: result.provider_ref || withdrawal.id,
        payment_method: withdrawal.payment_method,
        status: 'completed',
        metadata: { withdrawal_id: withdrawal.id },
      }, { transaction: t });
    }

    await smsService.sendWithdrawalUpdate(user.phone, withdrawal.amount, newStatus, user.id);

    logger.info(`Withdrawal ${newStatus}: ${withdrawalId} amount=${withdrawal.amount}`);
    return { status: newStatus };
  });
});

withdrawalQueue.on('failed', (job, err) => {
  logger.error(`Withdrawal job failed: ${job.data.withdrawalId}`, err.message);
});

module.exports = { withdrawalQueue };

/* ─────────────────────────────────────────────────────────────────────────── */

/**
 * SMS Retry Job
 */
const smsService2 = require('../services/sms/smsService');
const { SmsLog } = require('../models');

const smsQueue = new Bull('sms-retry', {
  redis: process.env.REDIS_URL,
  defaultJobOptions: { attempts: 3, backoff: { type: 'fixed', delay: 60000 } },
});

smsQueue.process('retry', async (job) => {
  const { smsLogId } = job.data;
  await smsService2.retryFailedSMS(smsLogId);
});

smsQueue.on('failed', (job, err) => {
  logger.error(`SMS retry failed for log ${job.data.smsLogId}:`, err.message);
  SmsLog.update({ status: 'failed' }, { where: { id: job.data.smsLogId } });
});

module.exports.smsQueue = smsQueue;
