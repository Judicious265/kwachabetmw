/**
 * Bet Settler Job
 * Fetches finished events, updates selection outcomes, settles tickets
 * Runs every 5 minutes
 */
const cron = require('node-cron');
const axios = require('axios');
const { Event, Market, TicketSelection, Ticket } = require('../models');
const { Op } = require('sequelize');
const bettingController = require('../controllers/bettingController');
const logger = require('../utils/logger');

async function settleFinishedEvents() {
  try {
    // Find events that should be finished
    const events = await Event.findAll({
      where: {
        status: 'upcoming',
        commence_time: { [Op.lte]: new Date(Date.now() - 2 * 60 * 60 * 1000) }, // 2h ago
      },
      limit: 50,
    });

    for (const event of events) {
      try {
        // In production: fetch actual results from API-Football or sports data provider
        // Here we mark event as finished and check if results are available
        await event.update({ status: 'finished' });

        // Update ticket selections for this event
        const selections = await TicketSelection.findAll({
          where: { event_id: event.id, status: 'pending' },
        });

        for (const sel of selections) {
          // If result is known, update selection
          if (event.result) {
            const won = (
              (sel.selection === event.home_team && event.result === 'home') ||
              (sel.selection === event.away_team && event.result === 'away') ||
              (sel.selection === 'Draw' && event.result === 'draw')
            );
            await sel.update({ status: won ? 'won' : 'lost', settled_at: new Date() });
          }
        }

        // Try to settle all tickets touching this event
        const ticketIds = [...new Set(selections.map(s => s.ticket_id))];
        for (const ticketId of ticketIds) {
          await bettingController.settleBet(ticketId);
        }

        logger.info(`Settled event: ${event.home_team} vs ${event.away_team}`);
      } catch (err) {
        logger.error(`Failed to settle event ${event.id}:`, err.message);
      }
    }
  } catch (err) {
    logger.error('Bet settler error:', err);
  }
}

cron.schedule('*/5 * * * *', settleFinishedEvents);

module.exports = { settleFinishedEvents };
