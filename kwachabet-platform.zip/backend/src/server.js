/**
 * Kwacha Bet - Main Server
 * Production-ready Express.js API server
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const http = require('http');
const WebSocket = require('ws');
const { sequelize } = require('./config/database');
const { redisClient } = require('./config/redis');
const logger = require('./utils/logger');
const { setupWebSocket } = require('./services/odds/websocketServer');

// Route imports
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const walletRoutes = require('./routes/wallet');
const bettingRoutes = require('./routes/betting');
const oddsRoutes = require('./routes/odds');
const paymentRoutes = require('./routes/payments');
const adminRoutes = require('./routes/admin');
const bonusRoutes = require('./routes/bonus');
const sportsRoutes = require('./routes/sports');

const app = express();
const server = http.createServer(app);

// ─── Security Middleware ─────────────────────────────────────────────────────

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      connectSrc: ["'self'", 'wss://api.kwachabet.mw'],
    },
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
}));

app.use(cors({
  origin: [process.env.FRONTEND_URL, process.env.ADMIN_URL],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
}));

// ─── Rate Limiting ────────────────────────────────────────────────────────────

const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  message: { error: 'Too many requests, please try again later.' },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Too many auth attempts. Try again in 15 minutes.' },
});

const otpLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { error: 'OTP request limit reached. Try again in 1 hour.' },
});

app.use(globalLimiter);
app.use(morgan('combined', { stream: { write: msg => logger.info(msg.trim()) } }));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// ─── Health Check ─────────────────────────────────────────────────────────────

app.get('/health', async (req, res) => {
  const dbOk = await sequelize.authenticate().then(() => true).catch(() => false);
  const redisOk = redisClient.isReady;
  res.status(dbOk && redisOk ? 200 : 503).json({
    status: dbOk && redisOk ? 'healthy' : 'degraded',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    services: { database: dbOk, redis: redisOk },
  });
});

// ─── API Routes ───────────────────────────────────────────────────────────────

app.use('/api/v1/auth', authLimiter, authRoutes);
app.use('/api/v1/auth/otp', otpLimiter);
app.use('/api/v1/users', userRoutes);
app.use('/api/v1/wallet', walletRoutes);
app.use('/api/v1/betting', bettingRoutes);
app.use('/api/v1/odds', oddsRoutes);
app.use('/api/v1/payments', paymentRoutes);
app.use('/api/v1/admin', adminRoutes);
app.use('/api/v1/bonus', bonusRoutes);
app.use('/api/v1/sports', sportsRoutes);

// Payment webhooks (no auth, but signature verified in controller)
app.use('/webhooks/paychangu', express.raw({ type: '*/*' }), require('./routes/webhooks'));

// ─── Error Handling ───────────────────────────────────────────────────────────

app.use((req, res) => res.status(404).json({ error: 'Route not found' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  logger.error(`${err.status || 500} - ${err.message} - ${req.originalUrl} - ${req.ip}`);
  if (process.env.NODE_ENV === 'production') {
    return res.status(err.status || 500).json({ error: 'Internal server error' });
  }
  res.status(err.status || 500).json({ error: err.message, stack: err.stack });
});

// ─── WebSocket Server ─────────────────────────────────────────────────────────

const wss = new WebSocket.Server({ server, path: '/ws/odds' });
setupWebSocket(wss);

// ─── Startup ──────────────────────────────────────────────────────────────────

async function start() {
  try {
    await sequelize.authenticate();
    logger.info('✅ Database connected');

    await redisClient.connect();
    logger.info('✅ Redis connected');

    // Start background jobs
    require('./jobs/oddsPoller');
    require('./jobs/betSettler');
    require('./jobs/withdrawalProcessor');
    require('./jobs/fraudScanner');
    require('./jobs/smsRetry');

    const PORT = process.env.PORT || 5000;
    server.listen(PORT, () => {
      logger.info(`🚀 Kwacha Bet API running on port ${PORT}`);
      logger.info(`🌐 Environment: ${process.env.NODE_ENV}`);
    });
  } catch (err) {
    logger.error('Failed to start server:', err);
    process.exit(1);
  }
}

start();

module.exports = app; // for tests
