/**
 * Authentication Middleware
 * Validates JWT tokens, checks user status, enforces roles
 */

const jwt = require('jsonwebtoken');
const { User } = require('../models');
const { cache } = require('../config/redis');

exports.authenticate = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    const token = header.slice(7);

    // Check token blacklist (for logged out tokens)
    const blacklisted = await cache.get(`blacklist:${token.slice(-16)}`);
    if (blacklisted) {
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findByPk(decoded.sub, {
      attributes: ['id','phone','full_name','is_active','is_suspended','is_admin','risk_score'],
    });

    if (!user) return res.status(401).json({ error: 'User not found.' });
    if (!user.is_active) return res.status(403).json({ error: 'Account deactivated.' });
    if (user.is_suspended) {
      return res.status(403).json({ error: 'Account suspended. Contact support@kwachabet.mw' });
    }

    req.user = user;
    req.token = token;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token.' });
    }
    next(err);
  }
};

exports.requireAdmin = (req, res, next) => {
  if (!req.user?.is_admin) {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
};

exports.requirePinVerified = (req, res, next) => {
  const pinToken = req.headers['x-pin-token'];
  if (!pinToken) {
    return res.status(403).json({ error: 'PIN verification required for this action.' });
  }

  try {
    const decoded = jwt.verify(pinToken, process.env.JWT_SECRET);
    if (decoded.scope !== 'pin_verified' || decoded.sub !== req.user.id) {
      throw new Error('Invalid PIN token');
    }
    next();
  } catch {
    return res.status(403).json({ error: 'PIN token invalid or expired. Verify your PIN again.' });
  }
};
