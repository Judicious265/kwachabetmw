const crypto = require('crypto');

exports.generateOTP = (length = 6) => {
  const digits = '0123456789';
  let otp = '';
  const bytes = crypto.randomBytes(length);
  for (let i = 0; i < length; i++) {
    otp += digits[bytes[i] % 10];
  }
  return otp;
};

exports.generateReferralCode = () => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  const bytes = crypto.randomBytes(8);
  for (let i = 0; i < 8; i++) code += chars[bytes[i] % chars.length];
  return code;
};

exports.maskPhone = (phone) => {
  if (!phone || phone.length < 8) return phone;
  return phone.slice(0, 5) + '****' + phone.slice(-3);
};

exports.formatMWK = (amount) =>
  `MWK ${parseFloat(amount).toLocaleString('en-MW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

exports.sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
